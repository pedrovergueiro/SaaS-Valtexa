"""Folhas 36 a 40: o que o V4 acrescentou — mastro, usinagem VMS e módulos de sensor.

A folha 19 mostra o posto de sensor montado. Estas cinco respondem o resto do pedido do
V4: por que o mastro engrossou, como se usina a interface, onde estão as nove câmeras, como
se troca uma em campo e o que a provisão de satélite realmente aceita.

Nenhum número é digitado aqui: tudo vem de `revisao-h/mastro.py` e `revisao-h/modular.py`.
"""
import math

import modelo as M
from folhas import (D, Folha, desenha_oculto, esc, iso_no_retangulo, recorta_caixa,
                    so, tabela, tag, vista_no_retangulo)
from folhas_b import _modular
from desenho import (Vista, balao, chamada, cota_h, cota_v, cruz_centro, desenha,
                     desenha_iso, linha_centro, num, rotulo, T)

_MAST = None


def _mastro_mod():
    global _MAST
    if _MAST is None:
        import importlib.util
        import pathlib
        cam = pathlib.Path(__file__).resolve().parent.parent / 'revisao-h' / 'mastro.py'
        esp = importlib.util.spec_from_file_location('mastro_h', cam)
        mod = importlib.util.module_from_spec(esp)
        esp.loader.exec_module(mod)
        _MAST = mod
    return _MAST


TXT_X, TXT_W = 232.0, 178.0


# ======================================================================== F36
def f36():
    F = Folha(36, escala='—', material='M-10 Al 6061-T6 · tubo Ø32×2')
    MA = _mastro_mod()
    f = MA.frequencia()
    ex = MA.excitacao()
    v = MA.veredito()
    comp = MA.comparacao_secoes()

    # ---- gráfico: frequência por seção, contra o requisito e a excitação
    x0, y0, w, h = 30.0, 150.0, 180.0, 110.0
    fmax = 14.0
    F.s.rect(x0, y0 - h, x0 + w, y0, 'hid0')
    for i in range(0, 15, 2):
        yy = y0 - h * i / fmax
        F.s.ln(x0, yy, x0 + w, yy, 'hid0')
        F.s.tx(x0 - 2, yy + 1, f'{i}', 2.4, a='end', c='tx sec')
    F.s.tx(x0 - 2, y0 - h - 5, 'Hz', 2.4, a='end', c='tx sec')
    for (val, cor, rot) in ((MA.REQUISITO_FREQ_HZ, 'cl', 'requisito 7,5 Hz'),
                            (ex['maior_Hz'], 'ref', f'excitação {ex["maior_Hz"]:.1f} Hz')):
        yy = y0 - h * val / fmax
        F.s.ln(x0, yy, x0 + w, yy, cor)
        F.s.tx(x0 + w + 2, yy + 1, rot, 2.4, a='start', c='tx sec')
    for i, c in enumerate(comp):
        xx = x0 + w * (i + 0.5) / len(comp)
        hh = h * min(c['freq_Hz'] / fmax, 1.0)
        atual = abs(c['d'] - M.D_MASTRO) < 0.1 and abs(c['parede'] - M.E_MASTRO) < 0.1
        F.s.rect(xx - 11, y0 - hh, xx + 11, y0, 'vis' if atual else 'hid')
        F.s.tx(xx, y0 - hh - 3, f'{c["freq_Hz"]:.1f}', 2.5, peso=700)
        F.s.tx(xx, y0 + 5, f'Ø{num(c["d"], 0)}×{num(c["parede"], 1)}', 2.3, c='tx sec')
    rotulo(F.s, x0 + w / 2, y0 + 16, '1ª FREQUÊNCIA DE FLEXÃO POR SEÇÃO DE TUBO', None,
           'barra cheia = a seção adotada no V4')

    # ---- mastro em elevação, com as cotas de câmera
    pe = recorta_caixa([p for p in M.mastro() + M.base_mastro() + M.suportes_camera()
                        if p.centro()[1] > 0], y=(0.0, 400.0))
    vl = vista_no_retangulo(pe, 'lateral_e', 32, 170, 112, 272)
    desenha(F.s, vl, pe)
    for z in M.CAMERAS_Z:
        q = vl.P((0, M.Y_MASTRO, z))
        cruz_centro(F.s, q[0], q[1], 3)
        F.s.tx(q[0] + 16, q[1] + 1, f'Z {num(z, 0)}', 2.4, a='start', c='tx sec')
    a, b = vl.P((0, 0, M.Z_LUVA[1])), vl.P((0, 0, M.Z_TOTAL))
    cota_v(F.s, a[1], b[1], 30, None, None, valor=M.Z_TOTAL - M.Z_LUVA[1], lado_txt=-1)
    rotulo(F.s, 72, 278, 'MASTRO — ELEVAÇÃO', esc(vl), 'engaste no topo da luva')

    F.bloco(TXT_X, 22, TXT_W, f'''
<h3>Por que o mastro engrossou de Ø25 para Ø32</h3>
<p>O caso 6 do FEA — "1ª frequência do mastro ≥ 7,5 Hz" — estava aberto desde a Rev E e
nunca tinha sido verificado. O V4 verificou, e o resultado obrigou a mexer.</p>
{tabela(['Grandeza', 'Ø25×2 (V3)', 'Ø32×2 (V4)'], [
    ['Momento de inércia', f'{comp[0]["I"]:.0f} mm⁴', f'{[c for c in comp if c["d"] == 32][0]["I"]:.0f} mm⁴'],
    ['1ª frequência', f'<b>{comp[0]["freq_Hz"]:.2f} Hz</b>',
     f'<b>{[c for c in comp if c["d"] == 32][0]["freq_Hz"]:.2f} Hz</b>'],
    ['Contra o requisito de 7,5 Hz', '<b>reprovado</b>', 'aprovado'],
    ['Contra a excitação do terreno', f'razão 1,16', f'razão {v["razao"]:.2f}'],
    ['Rotação da câmera alta sob galho', f'{comp[0]["rotacao_camera_alta_deg"]:.2f}°',
     f'{[c for c in comp if c["d"] == 32][0]["rotacao_camera_alta_deg"]:.2f}°'],
    ['Erro de apontamento a 10 m', f'{comp[0]["erro_a_10m_mm"]:.0f} mm',
     f'{[c for c in comp if c["d"] == 32][0]["erro_a_10m_mm"]:.0f} mm'],
    ['Massa dos dois mastros', '—', f'+{[c for c in comp if c["d"] == 32][0]["delta_massa_total"]:.2f} kg'],
], col=[42, 29, 29])}
<p>Com Ø25 o mastro estava a <b>1,16 vez</b> da excitação estimada do terreno — ou seja,
praticamente em ressonância. Não é margem apertada, é a faixa onde a resposta amplifica.
{tag('CALC')}</p>
<p class="mini">A luva M-01 acompanha (Ø42×5, era Ø34×4,5) e o eixo do mastro recua de
|Y| 280 para 276: a luva Ø42 em 280 chegaria a 301, fora do envelope de 600.</p>

<h3>De onde vem a excitação</h3>
{tabela(['Fonte', 'Frequência', 'Origem'], [
    [f'Terreno a {MA.VELOCIDADE_MS} m/s, onda de {MA.PASSO_IRREGULARIDADE_M} m',
     f'{ex["terreno_Hz"]:.2f} Hz', tag('CALC')],
    ['Suspensão pneumática (frequência de canto)', f'{ex["suspensao_Hz"]:.2f} Hz', tag('CALC')],
    ['Rotação da roda', f'{ex["rotacao_da_roda_Hz"]:.2f} Hz', tag('CALC')],
], col=[52, 24, 24])}
<p class="mini">O comprimento de onda de {MA.PASSO_IRREGULARIDADE_M} m é
{tag('A VALIDAR')} — critério de projeto, não medição. É o ensaio V-12 que fecha esta
margem, e fechá-la medindo é melhor que engrossar o tubo às cegas.</p>''')

    F.bloco(TXT_X, 176, TXT_W, f'''
<h3>Rigidez do mastro ≠ isolamento do sensor</h3>
<p>São coisas opostas, e o V4 escolhe uma.</p>
{tabela(['', 'Enrijecer o mastro', 'Isolar a câmera'], [
    ['O que faz', 'sobe a frequência própria para longe da excitação',
     'desacopla a câmera do mastro'],
    ['Efeito na imagem', 'reduz a amplitude do movimento', 'reduz o borrão de alta frequência'],
    ['Efeito na calibração', '<b>nenhum</b> — a câmera segue solidária ao rover',
     '<b>destrói</b> — a extrínseca passa a depender da aceleração'],
], col=[22, 39, 39])}
<p>A fusão trata a extrínseca como constante. Num mount isolado ela deixa de ser, e o erro
resultante não é um offset que a calibração corrija — é função do movimento. Entre imagem
com algum borrão e nuvem de pontos com erro de origem desconhecida, a primeira é
recuperável.</p>
<p><b>Decisão: câmera rígida. O único sensor isolado é o LiDAR</b>, nos coxins G-08 que já
existem desde a Rev E — e isolar o LiDAR está certo porque ele mede distância instantânea,
não integra imagem no tempo.</p>
<ol class="notas">
<li>Massa da OAK-D é {tag('A VALIDAR')}: {MA.MASSA_OAKD:.2f} kg é estimativa. Mesmo com
0,50 kg por câmera a seção Ø32 continua acima do requisito. {tag('CALC')}</li>
<li>A tensão na raiz com galho de {MA.GALHO_N:.0f} N é
{MA.tensao_mastro()["sigma_MPa"]:.0f} MPa, FS {MA.tensao_mastro()["fs"]:.2f}. O galho
governa, não o vento. {tag('CALC')}</li>
</ol>''')
    return F


# ======================================================================== F37
def f37():
    F = Folha(37, escala='1:1', material='T-02/T-03 Al 6061-T6 · pinos Inox 304',
              tolerancia='ISO 2768-mK · pinos ISO 286')
    MD = _modular()
    from folhas_w import _tab_ops
    rep = MD.repetibilidade()

    # prato T-02 em planta, 1:1
    cx, cy = 86.0, 74.0
    hw, hh = M.VMS_PRATO[0] / 2, M.VMS_PRATO[1] / 2
    F.s.rect(cx - hw, cy - hh, cx + hw, cy + hh, 'vis')
    for sx in (1, -1):
        for sz in (1, -1):
            F.s.circ(cx + sx * M.VMS_FUROS[0] / 2, cy + sz * M.VMS_FUROS[1] / 2, 2.75, 'vis')
    F.s.circ(cx, cy, M.D_PINO_REF / 2, 'vis')
    F.s.circ(cx, cy - M.Z_PINO_GIRO, M.D_PINO_GIRO / 2, 'vis')
    linha_centro(F.s, cx - hw - 6, cy, cx + hw + 6, cy)
    linha_centro(F.s, cx, cy - hh - 6, cx, cy + hh + 6)
    cota_h(F.s, cx - M.VMS_FUROS[0] / 2, cx + M.VMS_FUROS[0] / 2, cy + hh + 10,
           None, None, valor=M.VMS_FUROS[0])
    cota_h(F.s, cx - hw, cx + hw, cy + hh + 18, None, None, valor=M.VMS_PRATO[0])
    cota_v(F.s, cy - M.VMS_FUROS[1] / 2, cy + M.VMS_FUROS[1] / 2, cx - hw - 10,
           None, None, valor=M.VMS_FUROS[1])
    cota_v(F.s, cy - M.Z_PINO_GIRO, cy, cx - hw - 18, None, None,
           valor=M.Z_PINO_GIRO, lado_txt=-1)
    chamada(F.s, cx, cy, 150, 36, [f'Ø{num(M.D_PINO_REF, 0)} H7 · PINO DE REFERÊNCIA',
                                   'prensado em T-02, folgado em T-03'], lado=1)
    chamada(F.s, cx, cy - M.Z_PINO_GIRO, 150, 52,
            [f'Ø{num(M.D_PINO_GIRO, 0)} H7 · anti-giro'], lado=1)
    chamada(F.s, cx + M.VMS_FUROS[0] / 2, cy + M.VMS_FUROS[1] / 2, 150, 118,
            ['4× Ø5,5 — M5, só aperto', 'não posicionam nada'], lado=1)
    rotulo(F.s, cx, cy + hh + 30, 'PADRÃO VMS-60', '1:1',
           'a face que não muda quando o sensor muda')

    # adaptador T-03
    cx2, cy2 = 86.0, 196.0
    F.s.rect(cx2 - hw, cy2 - hh, cx2 + hw, cy2 + hh, 'vis')
    for sx in (1, -1):
        for sz in (1, -1):
            F.s.circ(cx2 + sx * M.VMS_FUROS[0] / 2, cy2 + sz * M.VMS_FUROS[1] / 2, 2.75, 'vis')
            F.s.circ(cx2 + sx * 25.0, cy2 + sz * 20.0, 1.7, 'hid')
    F.s.circ(cx2, cy2, M.D_PINO_REF / 2, 'vis')
    F.s.circ(cx2, cy2 - M.Z_PINO_GIRO, M.D_PINO_GIRO / 2, 'vis')
    linha_centro(F.s, cx2 - hw - 6, cy2, cx2 + hw + 6, cy2)
    linha_centro(F.s, cx2, cy2 - hh - 6, cx2, cy2 + hh + 6)
    cota_h(F.s, cx2 - 25.0, cx2 + 25.0, cy2 + hh + 10, None, None, valor=50)
    cota_v(F.s, cy2 - 20.0, cy2 + 20.0, cx2 - hw - 10, None, None, valor=40)
    chamada(F.s, cx2 + 25.0, cy2 - 20.0, 150, 246,
            ['furação do MODELO de sensor', 'tracejada: é a única coisa que muda'], lado=1)
    rotulo(F.s, cx2, cy2 + hh + 30, 'T-03 · ADAPTADOR', '1:1',
           '1 peça de chapa 6 por modelo adotado')

    F.bloco(TXT_X, 22, TXT_W, f'''
<h3>A conta que justifica o pino</h3>
<p>Dois pinos custam dois furos alargados e um minuto de prensa. O que eles compram:</p>
{tabela(['', 'Erro angular', 'Deslocamento a 10 m'], [
    [f'<b>Com pino</b> Ø{num(M.D_PINO_REF, 0)} H7/h6, braço {num(M.Z_PINO_GIRO, 0)} mm',
     f'<b>{rep["com_pino_deg"]:.3f}°</b>', f'<b>{rep["erro_com_pino_a_10m_mm"]:.1f} mm</b>'],
    ['Sem pino, M5 em furo Ø5,5', f'{rep["sem_pino_deg"]:.2f}°',
     f'{rep["erro_sem_pino_a_10m_mm"]:.0f} mm'],
], col=[46, 27, 27])}
<p>Fator {rep["fator"]:.0f}×. O limite para trocar um sensor <b>sem recalibrar</b> é
{MD.TOLERANCIA_EXTRINSECA_DEG:.1f}°, que é da ordem do próprio ruído de profundidade
estéreo a 10 m. Com pino, margem {MD.passa_sem_recalibrar()["margem"]:.1f}×. Sem pino,
reprovado. {tag('CALC')}</p>
{_tab_ops(['T-01', 'T-02', 'T-03'])}''')

    F.bloco(TXT_X, 178, TXT_W, f'''
<h3>Ajustes</h3>
{tabela(['Interface', 'Ajuste', 'O que garante'],
        [[a, b, c] for (a, b, c) in MD.__dict__.get('AJUSTES_VMS', [
            (f'Pino Ø{num(M.D_PINO_REF, 0)} no prato T-02', 'H7 / s6',
             'interferência: o pino fica no prato e nunca sai'),
            (f'Pino Ø{num(M.D_PINO_REF, 0)} no adaptador T-03', 'H7 / h6',
             'folga 0,024: entra à mão e repete 0,048°'),
            (f'Pino anti-giro Ø{num(M.D_PINO_GIRO, 0)}', 'H7 / h6', 'o braço angular'),
            ('Pino de índice de inclinação', 'H7 / h6',
             f'{M.N_INDICE} posições, passo {num(M.PASSO_INDICE_DEG, 0)}°'),
        ])], col=[40, 18, 42])}
<h3>A ordem da usinagem</h3>
<p>Os dois alojamentos de pino do prato T-02 são alargados <b>no mesmo setup</b>, e a cota
entre eles é {num(M.Z_PINO_GIRO, 0)} ± 0,02. É essa cota, e não o diâmetro dos pinos, que
determina a repetibilidade angular — errar 0,05 nela já vale mais que toda a folga dos
ajustes somada.</p>
<ol class="notas">
<li>Os pinos ISO 2338 são <b>comprados</b>, não usinados: F-40 (Ø8 h6) e F-41/F-42 (Ø6 h6).</li>
<li>O furo do sensor no T-03 é {tag('A VALIDAR')} — a furação real da OAK-D é a pendência
P-06. Os 4 furos Ø3,4 em 50 × 40 são <b>provisão</b>, não cota de fabricação.</li>
<li>Um modelo novo de sensor = <b>uma</b> peça nova de chapa 6 cortada a laser. Nada mais
do posto muda.</li>
</ol>''')
    return F


# ======================================================================== F38
def f38():
    F = Folha(38, escala='1:8', material='—')
    MD = _modular()
    todo = M.conjunto('AB') + M.referencias()
    cam = iso_no_retangulo(todo, 26, 20, 206, 196, 7.0, az=-128, el=20)
    desenha_iso(F.s, cam, todo)
    postos = [('C1 esq.', (0, M.Y_MASTRO, M.CAMERAS_Z[0])),
              ('C2 esq.', (0, M.Y_MASTRO, M.CAMERAS_Z[1])),
              ('C3 esq.', (0, M.Y_MASTRO, M.CAMERAS_Z[2])),
              ('C4 dir.', (0, -M.Y_MASTRO, M.CAMERAS_Z[0])),
              ('C5 dir.', (0, -M.Y_MASTRO, M.CAMERAS_Z[1])),
              ('C6 dir.', (0, -M.Y_MASTRO, M.CAMERAS_Z[2])),
              ('C7 front.', (M.X_CAM_FRENTE, 0, M.Z_CAM_EXTREMIDADE)),
              ('C8 tras.', (M.X_CAM_TRAS, 0, M.Z_CAM_EXTREMIDADE)),
              ('C9 raiz', (430.0, 0, 298.0))]
    for (nome, p) in postos:
        q = cam.P(p)
        balao(F.s, q[0] + 10, q[1] - 6, nome.split()[0], alvo=q)
    rotulo(F.s, 116, 204, 'OS NOVE POSTOS DE SENSOR', '1:8',
           'todos com a mesma face VMS-60')

    linhas = [[f'<b>{n}</b>', o, f'{z:.0f}', c, aj] for (n, o, z, c, aj) in [
        ('C1 / C4', 'mastro, 1º andar', M.CAMERAS_Z[0], 'inspeção', 'altura e inclinação'),
        ('C2 / C5', 'mastro, 2º andar', M.CAMERAS_Z[1], 'inspeção', 'altura e inclinação'),
        ('C3 / C6', 'mastro, 3º andar', M.CAMERAS_Z[2], 'inspeção', 'altura e inclinação'),
        ('C7', 'sob o nariz do chassi', M.Z_CAM_EXTREMIDADE, 'navegação', 'inclinação'),
        ('C8', 'sob a traseira do chassi', M.Z_CAM_EXTREMIDADE, 'navegação', 'inclinação'),
        ('C9', 'sobre a janela de raiz, olhando para baixo', 298.0, 'inspeção', 'fixa'),
    ]]
    F.bloco(26, 214, 180, f'''
<h3>Os nove postos</h3>
{tabela(['Posto', 'Onde', 'Z', 'Classe', 'Ajuste'], linhas, col=[14, 40, 12, 17, 17])}
<p class="mini">C7, C8 e C9 são as três que o V3 não tinha de verdade: a frontal estava
DECLARADA nos documentos e não existia no desenho, a traseira não existia em lugar nenhum,
e a de raiz tinha suporte dedicado sem interface padronizada. {tag('NOVO')}</p>''')

    e = MD.energia()
    n = MD.rede()
    F.bloco(TXT_X, 22, TXT_W, f'''
<h3>Classes de sensor, e por que elas importam</h3>
{tabela(['Classe', 'O que significa para o software'],
        [[k, v] for k, v in MD.CLASSES.items()], col=[22, 78])}
<p>A distinção não é burocrática: <b>a ausência de uma câmera de inspeção não pode impedir
a inicialização nem a navegação</b>, e a ausência de LiDAR, GNSS ou IMU tem de impedir.
É requisito de software, não de hardware.</p>

<h3>Matriz de compatibilidade do posto VMS-60</h3>
{tabela(['Módulo', 'VMS?', 'Por quê'],
        [[c['modulo'], '<b>sim</b>' if c['cabe_vms'] else 'não',
          c['pendencia']] for c in MD.compatibilidade()], col=[30, 10, 60])}

<h3>Energia e rede com nove câmeras</h3>
{tabela(['Grandeza', 'Valor', 'Situação'], [
    [f'{e["n_oakd"]} × OAK-D a {e["w_por_oakd"]:.2f} W (teto 802.3af cl. 3)',
     f'{e["w_oakd"]:.1f} W', '—'],
    [f'{e["n_termica"]} × térmica opcional', f'{e["w_termica"]:.1f} W', 'opcional'],
    ['Terminal satelital (provisão)', f'{e["w_satelite"]:.0f} W', 'provisão'],
    ['<b>Total com perdas de PoE</b>', f'<b>{e["total_W"]:.0f} W</b>',
     f'conversor de {e["capacidade_dcdc_W"]:.0f} W: <b>cabe</b>, folga {e["folga_W"]:.0f} W'],
    ['Portas Ethernet necessárias', f'{n["portas_necessarias"]}',
     f'switch de {n["portas_do_switch"]}: <b>NÃO SERVE</b>'],
    ['Banda agregada', f'{n["banda_total_Mbps"]:.0f} Mbit/s',
     f'{n["ocupacao_uplink"] * 100:.0f} % de um uplink de 1 Gbit/s'],
], col=[42, 20, 38])}
<p><b>A 9ª câmera não dói na energia, dói na rede.</b> São 10 portas com o LiDAR, e o
switch PoE de 8 não tem como atender. Trocar por um de 12 portas PoE+ é
<b>item novo de BOM</b>, não ajuste de desenho — pendência P-31. {tag('CALC')}</p>''')
    return F


# ======================================================================== F39
def f39():
    F = Folha(39, escala='—', material='—')
    MD = _modular()
    F.bloco(26, 22, 190, f'''
<h3>Trocar um sensor em campo</h3>
<p>Nove passos, chave Allen de 3 mm e nada mais. O passo 5 é o que importa.</p>
{tabela(['n', 'O que fazer', 'Por quê'],
        [[a, b, c] for (a, b, c) in MD.PROCEDIMENTO_TROCA], col=[6, 58, 36])}
<p><b>Passo 5 — não tocar na braçadeira T-01.</b> É ela que define altura e azimute, e é a
única camada cuja alteração exige recalibrar a extrínseca. O adaptador sai e volta sobre
os pinos; a braçadeira fica onde está.</p>
<h3>Proteção, ameaça por ameaça</h3>
{tabela(['Ameaça', 'De onde vem a proteção'],
        [[a, b] for (a, b) in MD.PROTECAO_POR_ONDE], col=[32, 68])}''')

    F.bloco(TXT_X, 22, TXT_W, f'''
<h3>O que o software tem de fazer</h3>
{tabela(['Requisito', 'O que significa'],
        [[a, b] for (a, b) in MD.REQUISITOS_SOFTWARE], col=[30, 70])}
<p class="mini">O inventário de módulos por rover — posto, modelo, número de série, data
da última calibração — é interface com o SaaS e está como
<code>NOT_IMPLEMENTED</code>.</p>

<h3>Ensaios que esta arquitetura exige</h3>
{tabela(['Cód.', 'Ensaio', 'Aceite'],
        [[a, b, c] for (a, b, c) in MD.PLANO_DE_ENSAIO], col=[8, 26, 66])}
<p><b>Nenhum destes ensaios foi feito.</b> O V-10 é o que valida ou derruba o argumento do
pino, que é a base de toda esta arquitetura — enquanto ele não rodar, a repetibilidade de
{MD.repetibilidade()["com_pino_deg"]:.3f}° é cálculo, não medição. {tag('A VALIDAR')}</p>''')
    return F


# ======================================================================== F40
def f40():
    F = Folha(40, escala='1:5', material='T-07 Al 5052-H32 · chapa 4')
    MD = _modular()
    tampa = [p.como('ctx') for p in M.carenagens() if p.item in ('K-04', 'K-05', 'K-06')]
    sat = M.berco_satelite() + [p for p in M.satelite_ref()]
    outros = M.suporte_gnss() + M.suporte_lidar() + M.estop()
    vs = vista_no_retangulo(tampa + sat + outros, 'superior', 28, 24, 214, 170)
    desenha(F.s, vs, tampa + outros + sat)
    for cod, p, (dx, dy) in (('T-07', (M.X_SAT, 0, M.Z_SAT), (0, 0)),
                             ('G-06', (M.X_LIDAR, 0, M.Z_TAMPA), (0, -12)),
                             ('N-01', (M.X_GNSS, 0, M.Z_TAMPA), (0, 12)),
                             ('K-06', (0, 200, M.Z_TAMPA), (14, 0))):
        q = vs.P(p)
        balao(F.s, q[0] + dx, q[1] + dy, cod, alvo=q if (dx or dy) else None)
    a, b = vs.P((M.X_SAT - M.SAT_ENVELOPE[0] / 2, 0, 0)), vs.P((M.X_SAT + M.SAT_ENVELOPE[0] / 2, 0, 0))
    cota_h(F.s, a[0], b[0], 180, None, None, valor=M.SAT_ENVELOPE[0])
    a, b = vs.P((0, -M.SAT_ENVELOPE[1] / 2, 0)), vs.P((0, M.SAT_ENVELOPE[1] / 2, 0))
    cota_v(F.s, a[1], b[1], 30, None, None, valor=M.SAT_ENVELOPE[1], lado_txt=-1)
    rotulo(F.s, 120, 188, 'DECK — O QUE JÁ OCUPA E O QUE SOBRA', esc(vs),
           'vista superior, tampas em contexto')

    F.bloco(26, 198, 190, f'''
<h3>Provisão de comunicação por satélite — e o que ela não resolve</h3>
<p>O V3 <b>não tinha provisão nenhuma</b>: a busca por "Starlink" em todo o projeto dava
zero ocorrências — nem suporte, nem massa, nem consumo. O V4 abre a provisão, e abre com o
número honesto do que cabe. {tag('NOVO')}</p>
{tabela(['Requisito do terminal', 'Valor'], [
    ['Envelope máximo (L × W × H)',
     f'<b>{num(M.SAT_ENVELOPE[0], 0)} × {num(M.SAT_ENVELOPE[1], 0)} × '
     f'{num(M.SAT_ENVELOPE[2], 0)} mm</b>'],
    ['Fixação', f'6 × M5 em porca-rebite, malha {num(190, 0)} × {num(210, 0)}'],
    ['Passagem de cabo', 'Ø32 central, com passa-cabo'],
    ['Consumo reservado no orçamento', f'{MD.W_SATELITE:.0f} W'],
    ['Interface', 'Ethernet — porta no switch PoE+ de 12 portas (P-31)'],
], col=[46, 54])}
<p><b>Um terminal de ~300 × 260 mm — que é a classe do Starlink Mini — NÃO CABE nesta
provisão.</b> O deck já tem o suporte do LiDAR em |X| 215…345, a antena GNSS em 295…405, a
faixa central em |X| ≤ 55 e o E-STOP em 420…500. O único vão contínuo é X −290…−60, e ele
dá {num(M.SAT_ENVELOPE[0], 0)} mm. Caber exigiria deslocar o LiDAR ou o GNSS — decisão de
projeto, não de desenho. Pendência <b>P-32</b>.</p>''')

    F.bloco(TXT_X, 22, TXT_W, f'''
<h3>Pendências que o V4 abre</h3>
{tabela(['Cód.', 'Assunto', 'Grau', 'O que falta'],
        [[a, b, c, d_] for (a, b, c, d_) in MD.PENDENCIAS], col=[8, 24, 11, 57])}
<h3>Acima da linha de proteção Z 400</h3>
<p>A baseline exige que nada do corpo passe de Z {num(M.Z_PROT, 0)}. Três coisas passam, e
as três são antena ou sensor que precisa ver:</p>
{tabela(['Item', 'Topo', 'Por quê'], [
    ['N-01 · suporte da antena GNSS', f'Z {num(M.Z_GNSS[1], 1)}',
     'já no V3; a antena precisa de vista livre ao céu'],
    ['G-06 · suporte do LiDAR', f'Z {num(M.Z_BASE_LIDAR, 1)}',
     'já no V3; 360° de varredura'],
    ['T-07 · berço do terminal satelital',
     f'Z {num(M.Z_SAT + M.E_BERCO_SAT, 1)}', f'novo no V4; +{num(M.E_BERCO_SAT + 2, 0)} mm'],
], col=[40, 16, 44])}
<p class="mini">É exceção deliberada e já existente, não descuido: pôr antena abaixo da
linha de proteção é anular a antena. O que está acima de Z 400 é tudo removível e
sacrificável; a estrutura do corpo continua abaixo.</p>''')
    return F


FOLHAS_T = [f36, f37, f38, f39, f40]
