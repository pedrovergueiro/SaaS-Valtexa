"""Emite os documentos da Rev H em Markdown, a partir dos módulos de cálculo.

Três documentos saem daqui, e nenhum deles é escrito à mão:

* `VTX-RV4-MONTAGEM-H.md` — onde vai cada peça, em que ordem, com que aperto;
* `VTX-RV4-USINAGEM-H.md` — o roteiro de operações, peça por peça;
* `VTX-RV4-ESPACO-H.md` — o espaço interno medido e a conferência de interferência;
* `VTX-RV4-MASTRO-H.md` — rigidez do mastro, vibração e a decisão de não isolar a câmera;
* `VTX-RV4-MODULAR-H.md` — a interface VMS-60: repetibilidade, proteção, energia e banda.

A razão de serem gerados: são os documentos que mais se descolam do projeto quando
escritos à mão. Uma cota muda no `modelo.py`, o desenho acompanha porque é paramétrico, e
o texto fica para trás. Gerando, isso não acontece — e se o módulo de cálculo quebrar, o
documento não sai, que é o comportamento certo.

O que NÃO é gerado: o documento da suspensão, a auditoria, o registro de alterações e a
liberação. Esses são argumento de engenharia, e argumento não se extrai de geometria.

```
python relatorios.py           # escreve os três .md
python gerar_docs.py           # converte todos os .md desta pasta em PDF
```
"""

from __future__ import annotations

import pathlib
import sys

AQUI = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI.parent / 'chassi-gaiola'))
sys.path.insert(0, str(AQUI))

import modelo as M  # noqa: E402
import espaco as ES  # noqa: E402
import montagem as MO  # noqa: E402
import suspensao as SU  # noqa: E402
import usinagem as US  # noqa: E402
import mastro as MA  # noqa: E402
import modular as MD  # noqa: E402

CABECALHO = """> **VTX-RV4 · Revisão H · 11/10/2026**
> EMITIDO PARA COTAÇÃO E VALIDAÇÃO — NÃO LIBERADO PARA FABRICAÇÃO
>
> Documento **gerado** de `revisao-h/{origem}` sobre a geometria de
> `chassi-gaiola/modelo.py`. Não editar à mão: a próxima geração sobrescreve.
"""


def _tab(cab, linhas):
    out = ['| ' + ' | '.join(cab) + ' |',
           '|' + '|'.join(['---'] * len(cab)) + '|']
    for ln in linhas:
        out.append('| ' + ' | '.join(str(c) for c in ln) + ' |')
    return '\n'.join(out)


# ============================================================ montagem
def montagem_md() -> str:
    mapa = MO.mapa()
    p = [f'# Rover V4 — manual de montagem e posição das peças\n',
         CABECALHO.format(origem='montagem.py'),
         """
## Para que serve este documento

Para montar o rover sem adivinhar. Ele responde três perguntas por peça: **onde** ela vai,
**contra o quê** ela encosta, e **como** ela prende. As duas primeiras são medidas no
modelo paramétrico; a terceira é decisão de projeto declarada.

A coluna "encosta em" é a mais útil na bancada: se a peça vizinha listada não estiver no
lugar quando você for montar, a ordem está errada — volte à seção de sequência.

Referencial: origem no solo, no centro do polígono das quatro rodas. **X** para a frente,
**Y** para a esquerda, **Z** para cima (ISO 8855). Todas as coordenadas em mm.
"""]

    p.append('\n## Mapa de posições\n')
    p.append(f'{len(mapa)} códigos de peça fabricada. A coordenada é a caixa envolvente de '
             'UM exemplar — os demais são espelhados em X, em Y ou nos dois.\n')
    grupo = None
    for d in mapa:
        if d['grupo'] != grupo:
            grupo = d['grupo']
            p.append(f'\n### Grupo {grupo} — {M.GRUPOS[grupo]}\n')
            p.append(_tab(['item', 'nome', 'qt', 'X', 'Y', 'Z', 'encosta em', 'como prende'], []))
        linha = [f'**{d["item"]}**', d['nome'], d['qtd'],
                 f'{d["x"][0]:.0f}…{d["x"][1]:.0f}',
                 f'{d["y"][0]:.0f}…{d["y"][1]:.0f}',
                 f'{d["z"][0]:.0f}…{d["z"][1]:.0f}',
                 ', '.join(d['vizinhas']) or '—',
                 d['como'] + (f' · **{d["torque"]:.0f} N·m**' if d['torque'] else '')]
        p.append('| ' + ' | '.join(str(c) for c in linha) + ' |')

    p.append('\n\n## Sequência de montagem\n')
    p.append('Quinze etapas. A razão de cada uma estar nessa posição vem antes das '
             'instruções, de propósito: é a razão que diz o que acontece se alguém '
             'inverter duas etapas.\n')
    for (n, titulo, razao, notas) in MO.SEQUENCIA:
        p.append(f'\n### {n}. {titulo}\n')
        p.append(f'{razao}\n')
        for nt in notas:
            p.append(f'- {nt}')

    p.append('\n\n## Torques de aperto\n')
    p.append(_tab(['Rosca', 'N·m', 'Onde'],
                  [[r, f'{n:.1f}', o] for (r, n, o) in MO.TORQUES]))
    p.append(f'\n{MO.TORQUES.__doc__ or ""}\n' if False else '')
    p.append("""
Inox A4-70 lubrificado, a 70 % do escoamento. **O M8 da suspensão aperta quatro peças em
série** — berço do fole, bucha de compressão, chapa de fundo e berço do pivô — com duas
delas em alumínio. É a bucha de compressão que define o torque: sem ela, 25 N·m amassam o
tubo 30×30×2 e o aperto se perde na primeira semana de campo.
""")

    p.append('\n## Conferências de aceite\n')
    p.append(_tab(['O que medir', 'Critério', 'Por que importa'],
                  [[o, c, por] for (o, c, por) in MO.CONFERENCIAS]))

    p.append("""
## O que não montar ainda

Três itens deste projeto não existem como componente escolhido, e improvisar qualquer um
deles na bancada custa a desmontagem:

1. **O fole W-15.** Nenhum modelo comercial escolhido (P-20). A interface está desenhada e
   aceita qualquer fole que feche a folha de requisitos da folha 07 — e aceita igualmente
   um cilindro pneumático de mesma área. Um fole fora de requisito muda curso, pressão e
   altura, e nenhum dos três se ajusta depois.
2. **A bucha autolubrificante do pivô** Ø23/Ø20 (P-21). O alojamento está em Ø23 H7.
3. **A bateria.** A altura máxima medida na zona central é
   {alt:.0f} mm, e a caixa estimada tem 130. Ver `VTX-RV4-ESPACO-G`.
""".format(alt=ES.requisitos_de_componente()[0]['altura_maxima']))
    return '\n'.join(p)


# ============================================================ usinagem
def usinagem_md() -> str:
    p = [f'# Rover V4 — roteiro de usinagem\n',
         CABECALHO.format(origem='usinagem.py'),
         """
## Corte e usinagem não são a mesma coisa

Este documento separa as duas, porque elas custam diferente e porque a oficina as faz em
máquinas diferentes:

- **corte** — laser ou serra. Sai pronto do DXF 1:1 em `saida/dxf`, sem tolerância a
  controlar além do contorno;
- **usinagem** — torno, fresa, alargador. Exige operação, referência, tolerância e
  acabamento, e nada disso está no DXF.

**DXF não carrega tolerância.** Quem cortar pelo DXF e usinar sem ler esta tabela e as
folhas 28 a 31 produz peça fora de especificação em todos os furos de ajuste.

## A regra que organiza o roteiro

**Solda primeiro, tolerância depois.** Toda operação marcada *DEPOIS DA SOLDA* é
obrigatoriamente posterior: a solda distorce, e uma tolerância feita antes dela se perdeu
sem que ninguém perceba — até o eixo não entrar.
"""]

    p.append('\n## Resumo por peça\n')
    p.append(_tab(['item', 'nome', 'qt', 'material', 'ops', 'corte', 'usinagem', 'solda',
                   'ops × qt'],
                  [[f'**{r["item"]}**', r['nome'], r['qtd'], r['mat'], r['total'],
                    r['corte'], r['usinagem'], r['solda'], r['ops_por_conjunto']]
                   for r in US.resumo()]))

    p.append('\n\n## Roteiro detalhado\n')
    for it, ops in US.OPERACOES.items():
        g = US.geometria(it)
        if not g:
            continue
        p.append(f'\n### {it} — {M.ITENS[it]["nome"]}\n')
        p.append(f'{g["qtd"]} un · {g["mat"]} · {M.ITENS[it]["desc"]}\n')
        linhas = []
        for (n, op, fer, cota, acab) in ops:
            nat = ('**SOLDA**' if 'SOLDAR' in op
                   else ('corte' if ('laser' in fer or 'serra' in fer) else '**USINAR**'))
            linhas.append([f'{nat} {n}', op, fer, cota, acab])
        p.append(_tab(['op', 'operação', 'ferramenta', 'cota / tolerância', 'acabamento'],
                      linhas))

    p.append('\n\n## Ajustes e folgas\n')
    p.append(_tab(['Interface', 'Ajuste', 'O que ele garante'],
                  [[o, a, por] for (o, a, por) in US.AJUSTES]))

    p.append('\n\n## Notas gerais\n')
    for n in US.NOTAS:
        p.append(f'- {n}')

    c = US.confere()
    p.append('\n\n## Conferência automática\n')
    p.append(f'- roteiro declarado para peça que não existe no modelo: '
             f'**{c["sem_peca"] or "nenhuma"}**')
    p.append(f'- peça do grupo W sem roteiro declarado: '
             f'**{c["sem_roteiro"] or "nenhuma"}**')
    return '\n'.join(p)


# ============================================================ espaço
def espaco_md() -> str:
    it = ES.interferencias()
    v = ES.volume_interno()
    mp = ES.mapa_de_alturas()
    p = [f'# Rover V4 — espaço interno e interferência entre peças\n',
         CABECALHO.format(origem='espaco.py'),
         """
## Duas perguntas, as duas medidas

**As peças se batem?** Mede-se, par a par, se duas caixas envolventes se interpenetram.
O que nasce interpenetrado por projeto — bucha dentro do tubo, colar atravessando a chapa,
pino atravessando a parede — está na lista de encaixes previstos, cada um com a razão.
Qualquer par fora dessa lista é defeito.

**O que cabe lá dentro?** Varre-se o compartimento numa grade de 8 mm e mede-se a altura
livre célula por célula, descontando TODAS as peças do modelo.

### Por que isso precisou ser medido

Imagens conceituais em circulação afirmavam **95,6 L** de volume interno útil, calculados
como 850 × 450 × 250 mm. Nenhuma das três cotas existe no projeto: o compartimento tem
1046 de comprimento, 536 de largura livre e altura que **varia de ponto a ponto**, porque
as barras G-03 da gaiola descem a Z 377 e atravessam o rover em |X| 230 e 330.

O número real, medido, é o da seção seguinte.
"""]
    p.append(f'\n## Interferência entre peças\n')
    p.append(f'{it["pecas"]} peças fornecidas, {it["pares"]} pares verificados.\n')
    p.append(f'**Encaixes previstos: {len(it["previstos"])}**\n')
    p.append(_tab(['par', 'profundidade', 'razão'],
                  [[f'{a} × {b}', f'{f:.1f} mm', r]
                   for (a, b), (f, r) in sorted(it['previstos'].items())]))
    p.append(f'\n**Defeitos: {len(it["defeitos"]) or "nenhum"}**\n')
    if it['defeitos']:
        p.append(_tab(['par', 'profundidade'],
                      [[f'{a} × {b}', f'{f:.1f} mm'] for (a, b), f in sorted(it['defeitos'].items())]))

    p.append('\n\n## Volume interno\n')
    p.append(_tab(['Grandeza', 'Valor'], [
        [f'Caixa bruta do compartimento (1046 × 596 × {v["z_teto"] - v["z_piso"]:.0f})',
         f'{v["volume_bruto_L"]:.2f} L'],
        ['**Volume livre, descontada toda peça**', f'**{v["volume_livre_L"]:.2f} L**'],
        ['Maior altura livre contínua em qualquer ponto', f'{v["maior_vao_mm"]:.0f} mm'],
    ]))
    p.append('\n### Volume aproveitável por altura de componente\n')
    p.append(_tab(['Componente de até', 'Volume aproveitável'],
                  [[f'{h:.0f} mm', f'{vol:.2f} L'] for h, vol in sorted(v['por_altura_L'].items())]))
    p.append('\n### Área de piso por faixa de altura livre\n')
    p.append(_tab(['Faixa de altura livre', 'Área de piso'],
                  [[f'{k:.0f} a {k + 20:.0f} mm', f'{a:.0f} cm²']
                   for k, a in v['area_por_vao_cm2'].items()]))

    p.append('\n\n## Teto de altura por zona — para a folha de compra\n')
    p.append('É o jeito útil de entregar esta conferência: em vez de reprovar um componente '
             'estimado, dizer qual é o teto real da zona, para que a cota entre na folha de '
             'compra junto com a ficha técnica que falta.\n')
    p.append(_tab(['Zona', 'Altura máxima de componente', 'Área', 'Onde'],
                  [[r['zona'], f'**{r["altura_maxima"]:.0f} mm**', f'{r["area_cm2"]:.0f} cm²',
                    r['nota']] for r in ES.requisitos_de_componente()]))

    p.append('\n\n## Cada componente cabe em algum lugar contíguo?\n')
    p.append('Varredura da grade inteira, nas duas orientações. É a pergunta certa — '
             'diferente de "a altura média da zona dá".\n')
    linhas = []
    for (nome, zona, cl, cw, ch, origem) in ES.COMPONENTES:
        r = ES.cabe_em_pe(cl, cw, ch, mp)
        if r['cabe']:
            onde = (f'X {r["x"][0]:.0f}…{r["x"][1]:.0f} · Y {r["y"][0]:.0f}…{r["y"][1]:.0f} '
                    f'(livre {r["altura_livre"]:.0f} mm)')
            linhas.append([nome, f'{cl:.0f}×{cw:.0f}×{ch:.0f}', origem, '**CABE**', onde])
        else:
            linhas.append([nome, f'{cl:.0f}×{cw:.0f}×{ch:.0f}', origem, '**NÃO CABE**',
                           'nenhuma área contígua no compartimento'])
    p.append(_tab(['Componente', 'L×W×H', 'origem do dado', 'veredito', 'posição'], linhas))

    p.append("""

## O que isto responde e o que continua aberto

**Responde**: o volume interno real, a altura livre ponto a ponto, e se os componentes
estimados cabem onde o projeto os quer.

**Continua aberto**: as dimensões dos componentes. Toda linha da tabela acima é
ESTIMATIVA ou FAIXA de catálogo — nenhuma é ficha técnica de peça escolhida. Enquanto for
assim, as bandejas E-01/E-02 e os suportes M-20 **não são cotas de fabricação, são
provisões**. É a pendência P-05/P-13, e nenhuma conta deste documento a fecha.

### O achado que a Rev H produziu aqui

A bandeja de extremidade **E-02 encolheu**. Ela ia de |Y| 105 a 250 e colidia frontalmente
com o colar do fole, que ocupa |Y| 159…259. A faixa que sobra, entre a janela da câmera de
raiz (|Y| ≤ 95) e o colar, é de 100 a 152 mm. A bandeja perdeu mais da metade da área, e
isso é preço de ter suspensão — não erro de desenho.
""")
    return '\n'.join(p)


# ============================================================ mastro
def mastro_md() -> str:
    f = MA.frequencia()
    ex = MA.excitacao()
    v = MA.veredito()
    comp = MA.comparacao_secoes()
    atual = [c for c in comp if abs(c['d'] - M.D_MASTRO) < 0.1
             and abs(c['parede'] - M.E_MASTRO) < 0.1][0]
    v3 = comp[0]
    p = [f'# Rover V4 — rigidez do mastro e vibração dos sensores\n',
         CABECALHO.format(origem='mastro.py'),
         f"""
## O achado

O caso 6 do FEA — *"1ª frequência do mastro ≥ 7,5 Hz"* — estava aberto desde a Rev E e
**nunca tinha sido verificado**. O V4 verificou.

Com o tubo Ø25 × 2 herdado da baseline, a primeira frequência de flexão do mastro é
**{v3['freq_Hz']:.2f} Hz**. O requisito é 7,5. E a excitação estimada do terreno a
{MA.VELOCIDADE_MS} m/s é **{ex['terreno_Hz']:.2f} Hz** — razão de **1,16**.

1,16 não é margem apertada. É a faixa onde a resposta **amplifica**: o mastro estava
praticamente em ressonância com o chão da lavoura, com três câmeras no alto.

## A correção

| Grandeza | Ø25 × 2 (V3) | Ø32 × 2 (V4) |
|---|---|---|
| Momento de inércia | {v3['I']:.0f} mm⁴ | {atual['I']:.0f} mm⁴ |
| **1ª frequência de flexão** | **{v3['freq_Hz']:.2f} Hz** | **{atual['freq_Hz']:.2f} Hz** |
| Contra o requisito de 7,5 Hz | reprovado | aprovado |
| Razão contra a excitação | 1,16 | {v['razao']:.2f} |
| Rotação da câmera alta sob galho de {MA.GALHO_N:.0f} N | {v3['rotacao_camera_alta_deg']:.2f}° | {atual['rotacao_camera_alta_deg']:.2f}° |
| Erro de apontamento a 10 m | {v3['erro_a_10m_mm']:.0f} mm | {atual['erro_a_10m_mm']:.0f} mm |
| Massa dos dois mastros | — | +{atual['delta_massa_total']:.2f} kg |

A luva M-01 acompanha: Ø42 × 5, contra Ø34 × 4,5 do V3. E o eixo do mastro recua de
|Y| 280 para 276 — a luva Ø42 em 280 chegaria a 301, fora do envelope externo de 600.

## Todas as seções avaliadas

| Seção | I (mm⁴) | f (Hz) | Δmassa (2 mastros) | Rotação sob galho | Erro a 10 m |
|---|---|---|---|---|---|"""]
    for c in comp:
        marca = ' ← **adotada**' if c is atual else ('' if c['atende'] else ' ← abaixo do requisito')
        p.append(f"| {c['nome']}{marca} | {c['I']:.0f} | {c['freq_Hz']:.2f} | "
                 f"{c['delta_massa_total']:+.3f} kg | {c['rotacao_camera_alta_deg']:.2f}° | "
                 f"{c['erro_a_10m_mm']:.0f} mm |")

    p.append(f"""

## De onde vem a excitação

| Fonte | Frequência |
|---|---|
| Terreno a {MA.VELOCIDADE_MS} m/s, onda de {MA.PASSO_IRREGULARIDADE_M} m | {ex['terreno_Hz']:.2f} Hz |
| Suspensão pneumática (frequência de canto) | {ex['suspensao_Hz']:.2f} Hz |
| Rotação da roda | {ex['rotacao_da_roda_Hz']:.2f} Hz |

A suspensão pneumática **filtra** o terreno acima da própria frequência de
{ex['suspensao_Hz']:.2f} Hz. O que chega ao mastro é o que passa por ela.

> O comprimento de onda de {MA.PASSO_IRREGULARIDADE_M} m é **critério de projeto, não
> medição**. É o ensaio V-12 que fecha esta margem — e fechá-la medindo é melhor
> engenharia que engrossar o tubo às cegas.

## Sensibilidade à massa da câmera

A massa da OAK-D é **estimativa** (pendência P-06). O resultado é robusto a ela:

| Massa da câmera | Frequência | Atende? |
|---|---|---|""")
    for s in MA.sensibilidade():
        p.append(f"| {s['massa_camera']:.2f} kg | {s['freq_Hz']:.2f} Hz | "
                 f"{'sim' if s['atende'] else '**não**'} |")

    p.append(f"""

## Rigidez do mastro não é isolamento do sensor

O pedido do V4 manda diferenciar as duas coisas. A diferença não é de grau — é de sinal.

| | Enrijecer o mastro | Isolar a câmera |
|---|---|---|
| O que faz | sobe a frequência própria para longe da excitação | desacopla a câmera do mastro |
| Efeito na imagem | reduz a amplitude do movimento | reduz o borrão de alta frequência |
| Efeito na calibração | **nenhum** — a câmera segue solidária ao rover | **destrói** — a extrínseca passa a depender da aceleração |

{MA.PORQUE_NAO_ISOLAR_CAMERA}

### O único sensor isolado continua sendo o LiDAR

E isolar o LiDAR está certo, porque ele é o caso oposto: mede distância instantânea ponto
a ponto, não integra imagem no tempo, e a extrínseca dele precisa valer na média.

Os coxins G-08 já existem desde a Rev E. A conta de verificação:

| | Valor |
|---|---|
| 4 coxins a {MA.isolamento_lidar()['k_por_coxim_N_mm']:.0f} N/mm sob {MA.isolamento_lidar()['massa_isolada']:.2f} kg | {MA.isolamento_lidar()['freq_Hz']:.0f} Hz |
| Razão contra a excitação | {MA.isolamento_lidar()['razao']:.0f}× |
| Isola ou amplifica? | **{'isola' if MA.isolamento_lidar()['isola'] else 'amplifica'}** |

> Isolador só atenua acima de √2 vezes a própria frequência. Abaixo disso ele **amplifica**.
> A conta depende da massa do LiDAR, que é estimativa (P-11).

## Tensão no mastro

| | Valor |
|---|---|
| Carga de galho de projeto | {MA.GALHO_N:.0f} N na ponta |
| Momento na raiz | {MA.tensao_mastro()['momento_projeto_Nmm']:.0f} N·mm |
| Tensão | {MA.tensao_mastro()['sigma_MPa']:.1f} MPa |
| Fator de segurança | {MA.tensao_mastro()['fs']:.2f} |

{MA.tensao_mastro()['nota']}

## O que continua aberto

- **massa real da OAK-D** (P-06) — a frequência é robusta a ela, o apontamento não;
- **espectro real de vibração em campo** (ensaio V-12) — hoje a excitação é critério;
- **FEA do caso 6** — este cálculo é analítico, por Rayleigh, com forma suposta. Ele diz
  que Ø25 reprovava e que Ø32 passa; não substitui o modelo de elementos finitos.
""")
    return '\n'.join(p)


# ============================================================ modular
def modular_md() -> str:
    rep = MD.repetibilidade()
    pr = MD.passa_sem_recalibrar()
    pt = MD.protecao()
    e = MD.energia()
    n = MD.rede()
    p = [f'# Rover V4 — interface modular de sensores VMS-60\n',
         CABECALHO.format(origem='modular.py'),
         f"""
## O que separa "removível" de "modular"

Removível é qualquer coisa com parafuso. **Modular é o que se pode repor no mesmo lugar.**

A fusão de dados usa a matriz extrínseca de cada câmera — onde ela está e para onde aponta,
no referencial do rover — como **constante**, medida uma vez na calibração. Se trocar uma
câmera desloca a próxima em 1°, a calibração morre junto com a peça trocada, e o técnico
que fez a troca na lavoura degradou a navegação sem ter como perceber.

Por isso a face VMS-60 se apoia em **pino**, não em parafuso.

| Interface | Erro angular | Deslocamento a 10 m |
|---|---|---|
| **Pino Ø{M.D_PINO_REF:.0f} H7/h6 + anti-giro a {M.Z_PINO_GIRO:.0f} mm** | **{rep['com_pino_deg']:.3f}°** | **{rep['erro_com_pino_a_10m_mm']:.1f} mm** |
| Só parafuso M5 em furo Ø5,5 | {rep['sem_pino_deg']:.2f}° | {rep['erro_sem_pino_a_10m_mm']:.0f} mm |

Fator **{rep['fator']:.0f}×**. O limite para trocar sem recalibrar é
{MD.TOLERANCIA_EXTRINSECA_DEG:.1f}° — da ordem do próprio ruído de profundidade estéreo a
10 m. Com pino passa com margem {pr['margem']:.1f}×; sem pino, **não passa**.

Dois pinos custam dois furos alargados e um minuto de prensa.

## As três camadas

| Camada | Peça | O que define | Mexer nela exige |
|---|---|---|---|
| 1 · posição | T-01 braçadeira | altura e azimute no mastro | **recalibrar** a extrínseca |
| 2 · interface | T-02 prato VMS | os pinos e a inclinação indexada | recalibrar só se mudar o índice |
| 3 · adaptação | T-03 adaptador | a furação daquele modelo de sensor | **nada** — é a troca de campo |

Trocar a câmera mexe só na camada 3. **Não tocar na braçadeira** é a regra que protege a
calibração.

A inclinação é indexada por pino em {M.N_INDICE} posições, passo de
{M.PASSO_INDICE_DEG:.0f}° — de −{(M.N_INDICE - 1) / 2 * M.PASSO_INDICE_DEG:.0f}° a
+{(M.N_INDICE - 1) / 2 * M.PASSO_INDICE_DEG:.0f}°. Índice por pino repete; aperto por
atrito não.

## Proteção sem nada na frente da lente

O requisito diz: proteger contra impacto **sem grade, aro ou defletor diante das lentes**.
A geometria concorda, e não dá margem:

Com {MD.FOV_H_DEG:.0f}° de campo horizontal, qualquer peça a {pt['avanco_mm']:.0f} mm à
frente da lente teria de estar a **{pt['lateral_necessaria_mm']:.0f} mm** do eixo para não
aparecer na imagem. O prato tem {pt['meia_largura_do_prato_mm']:.0f} mm de meia-largura.
**Lateralmente não cabe** — e é por isso que o projeto não tem grade nenhuma.

Verticalmente cabe: {pt['avanco_mm']:.0f} mm à frente exigem
{pt['vertical_necessaria_mm']:.0f} mm acima, e o protetor T-05 tem
{pt['altura_do_protetor_mm']:.0f}, com {pt['folga_vertical_mm']:.0f} mm de folga.

Daí a solução: **sobrancelha superior sacrificial**, e nada ao lado nem à frente.

| Ameaça | De onde vem a proteção |
|---|---|"""]
    for (a, b) in MD.PROTECAO_POR_ONDE:
        p.append(f'| {a} | {b} |')

    p.append(f"""

{MD.NOTA_IP}

## Matriz de compatibilidade do posto VMS-60

| Módulo | Classe | Massa | Consumo | Cabe no VMS? | O que falta |
|---|---|---|---|---|---|""")
    for c in MD.compatibilidade():
        m = f"{c['massa']:.2f} kg" if c['massa'] else '—'
        w = f"{c['w']:.1f} W" if c['w'] else '—'
        p.append(f"| {c['modulo']} | {c['classe']} | {m} | {w} | "
                 f"{'**sim**' if c['cabe_vms'] else 'não'} | {c['pendencia']} |")

    p.append(f"""

### As classes não são burocracia

| Classe | O que significa para o software |
|---|---|""")
    for k, vdesc in MD.CLASSES.items():
        p.append(f'| {k} | {vdesc} |')
    p.append("""
**A ausência de uma câmera de inspeção não pode impedir a inicialização nem a navegação.**
A ausência de LiDAR, GNSS ou IMU tem de impedir. É requisito de software, e a distinção
existe para que o rover continue trabalhando com uma câmera queimada em vez de parar na
lavoura.

## Energia e rede com nove câmeras""")
    p.append(f"""
| Grandeza | Valor | Situação |
|---|---|---|
| {e['n_oakd']} × OAK-D a {e['w_por_oakd']:.2f} W (teto 802.3af classe 3) | {e['w_oakd']:.1f} W | — |
| {e['n_termica']} × térmica opcional | {e['w_termica']:.1f} W | opcional |
| Terminal satelital (provisão) | {e['w_satelite']:.0f} W | provisão |
| **Total com {(1 - e['rendimento_poe']) * 100:.0f} % de perda de PoE** | **{e['total_W']:.0f} W** | conversor de {e['capacidade_dcdc_W']:.0f} W: **cabe**, folga {e['folga_W']:.0f} W |
| Portas Ethernet necessárias | {n['portas_necessarias']} | switch de {n['portas_do_switch']}: **não serve** |
| Banda agregada | {n['banda_total_Mbps']:.0f} Mbit/s | {n['ocupacao_uplink'] * 100:.0f} % de um uplink de 1 Gbit/s |

**A 9ª câmera não dói na energia — dói na rede.** São 10 portas com o LiDAR, e o switch PoE
de 8 não atende. Trocar por um de 12 portas PoE+ é **item novo de BOM**, não ajuste de
desenho. Pendência P-31.

## O que o software tem de fazer

| Requisito | O que significa |
|---|---|""")
    for (a, b) in MD.REQUISITOS_SOFTWARE:
        p.append(f'| {a} | {b} |')

    p.append("""

## Trocar um sensor em campo

| n | O que fazer | Por quê |
|---|---|---|""")
    for (a, b, c) in MD.PROCEDIMENTO_TROCA:
        p.append(f'| {a} | {b} | {c} |')
    p.append("""
**O passo 5 é o que importa:** não tocar na braçadeira T-01. É ela que define altura e
azimute, e é a única camada cuja alteração exige recalibrar.

## Ensaios que esta arquitetura exige

| Cód. | Ensaio | Aceite |
|---|---|---|""")
    for (a, b, c) in MD.PLANO_DE_ENSAIO:
        p.append(f'| {a} | {b} | {c} |')
    p.append("""
**Nenhum destes ensaios foi feito.** O V-10 é o que valida ou derruba o argumento do pino,
que é a base de toda esta arquitetura — enquanto ele não rodar, a repetibilidade calculada
é cálculo, não medição.

## Pendências

| Cód. | Assunto | Grau | O que falta |
|---|---|---|---|""")
    for (a, b, c, d) in MD.PENDENCIAS:
        p.append(f'| **{a}** | {b} | {c} | {d} |')
    return '\n'.join(p)


def main() -> None:
    for nome, texto in (('VTX-RV4-MONTAGEM-H.md', montagem_md()),
                        ('VTX-RV4-USINAGEM-H.md', usinagem_md()),
                        ('VTX-RV4-ESPACO-H.md', espaco_md()),
                        ('VTX-RV4-MASTRO-H.md', mastro_md()),
                        ('VTX-RV4-MODULAR-H.md', modular_md())):
        (AQUI / nome).write_text(texto, encoding='utf8')
        print(f'  {nome:34} {len(texto) / 1024:6.1f} KB')


if __name__ == '__main__':
    main()
