# Rover V4 — interface modular de sensores VMS-60

> **VTX-RV4 · Revisão H · 11/10/2026**
> EMITIDO PARA COTAÇÃO E VALIDAÇÃO — NÃO LIBERADO PARA FABRICAÇÃO
>
> Documento **gerado** de `revisao-h/modular.py` sobre a geometria de
> `chassi-gaiola/modelo.py`. Não editar à mão: a próxima geração sobrescreve.


## O que separa "removível" de "modular"

Removível é qualquer coisa com parafuso. **Modular é o que se pode repor no mesmo lugar.**

A fusão de dados usa a matriz extrínseca de cada câmera — onde ela está e para onde aponta,
no referencial do rover — como **constante**, medida uma vez na calibração. Se trocar uma
câmera desloca a próxima em 1°, a calibração morre junto com a peça trocada, e o técnico
que fez a troca na lavoura degradou a navegação sem ter como perceber.

Por isso a face VMS-60 se apoia em **pino**, não em parafuso.

| Interface | Erro angular | Deslocamento a 10 m |
|---|---|---|
| **Pino Ø8 H7/h6 + anti-giro a 26 mm** | **0.048°** | **8.5 mm** |
| Só parafuso M5 em furo Ø5,5 | 1.10° | 192 mm |

Fator **23×**. O limite para trocar sem recalibrar é
0.1° — da ordem do próprio ruído de profundidade estéreo a
10 m. Com pino passa com margem 2.1×; sem pino, **não passa**.

Dois pinos custam dois furos alargados e um minuto de prensa.

## As três camadas

| Camada | Peça | O que define | Mexer nela exige |
|---|---|---|---|
| 1 · posição | T-01 braçadeira | altura e azimute no mastro | **recalibrar** a extrínseca |
| 2 · interface | T-02 prato VMS | os pinos e a inclinação indexada | recalibrar só se mudar o índice |
| 3 · adaptação | T-03 adaptador | a furação daquele modelo de sensor | **nada** — é a troca de campo |

Trocar a câmera mexe só na camada 3. **Não tocar na braçadeira** é a regra que protege a
calibração.

A inclinação é indexada por pino em 7 posições, passo de
10° — de −30° a
+30°. Índice por pino repete; aperto por
atrito não.

## Proteção sem nada na frente da lente

O requisito diz: proteger contra impacto **sem grade, aro ou defletor diante das lentes**.
A geometria concorda, e não dá margem:

Com 128° de campo horizontal, qualquer peça a 40 mm à
frente da lente teria de estar a **82 mm** do eixo para não
aparecer na imagem. O prato tem 36 mm de meia-largura.
**Lateralmente não cabe** — e é por isso que o projeto não tem grade nenhuma.

Verticalmente cabe: 40 mm à frente exigem
34 mm acima, e o protetor T-05 tem
40, com 6 mm de folga.

Daí a solução: **sobrancelha superior sacrificial**, e nada ao lado nem à frente.

| Ameaça | De onde vem a proteção |
|---|---|
| Galho vindo de frente | lente recuada 6 mm atrás da face do adaptador + sobrancelha T-05 avançando 40 mm acima do eixo óptico |
| Galho vindo de cima | sobrancelha T-05, que é a peça sacrificial: 2 parafusos M4 e troca em campo sem ferramenta especial |
| Galho vindo de fora para dentro | o protetor envolve o canto externo superior; o lado de dentro é protegido pelo próprio mastro |
| Pedra lançada pela roda | as câmeras de extremidade ficam SOB a chapa de fundo, com a chapa por cima e 60 mm de recuo da borda |
| Impacto no mastro inteiro | bainha anti-galho M-11 em UHMW-PE sobre o tubo, nos trechos entre câmeras |
| Chuva e lavagem | conector M12 codificação X por posto; a vedação é do conector, não de caixa — ver nota sobre IP |
| Poeira e lama | nenhuma fenda horizontal voltada para cima no posto VMS; o prato T-02 é inclinável e drena |
| Vibração | montagem RÍGIDA por decisão de projeto — ver `mastro.py` |


O projeto NÃO declara grau de proteção IP para o posto de sensor, e isso é deliberado.

Grau IP é resultado de ENSAIO num conjunto fechado, não propriedade de um conector
isolado. O que o projeto pode afirmar é o que especifica: conector M12 com codificação X,
que é o padrão de Ethernet industrial e existe em versões classificadas por fabricante. O
grau do POSTO montado — conector, cabo, passa-cabo e carcaça da câmera juntos — só sai do
ensaio, e está na lista de ensaios como V-11.

Declarar "IP67" aqui sem o ensaio seria inventar classificação, que é exatamente o que o
pedido do V4 proíbe.


## Matriz de compatibilidade do posto VMS-60

| Módulo | Classe | Massa | Consumo | Cabe no VMS? | O que falta |
|---|---|---|---|---|---|
| OAK-D Pro W PoE (base) | inspecao | 0.25 kg | 12.9 W | **sim** | desenho dimensional e furação reais (P-06); massa é ESTIMATIVA |
| Câmera térmica radiométrica compacta | inspecao | 0.20 kg | 3.0 W | **sim** | NENHUM MODELO ESCOLHIDO. Adaptador T-04 é requisito, não desenho |
| Câmera RGB alternativa (GigE industrial) | inspecao | 0.30 kg | 6.0 W | **sim** | furação própria: exige adaptador novo, que é 1 peça de chapa 6 |
| Sensor multiespectral | inspecao | 0.35 kg | 8.0 W | **sim** | modelo não escolhido; massa e consumo são FAIXA |
| LiDAR Livox Mid-360 | navegacao | 0.30 kg | — | não | NÃO vai em posto VMS: precisa de 360° livres e fica no alto da gaiola, em G-06 com coxins. É o único sensor que permanece ISOLADO — ver `mastro.py` |
| Antena GNSS RTK | navegacao | — | — | não | NÃO vai em posto VMS: precisa de vista livre ao céu e plano de terra. Fica em N-01, na tampa |
| IMU | navegacao | — | — | não | NÃO vai em posto VMS: tem de ficar o mais perto possível do CG, não no alto do mastro — no mastro ela mediria a vibração do mastro, não o movimento do rover |
| Terminal de comunicação por satélite | comunicacao | — | — | não | NÃO vai em posto VMS: berço próprio T-07 na tampa, envelope máximo 220 × 240 × 40 |


### As classes não são burocracia

| Classe | O que significa para o software |
|---|---|
| navegacao | Sensor de navegação — a ausência dele PARA o rover |
| inspecao | Sensor de inspeção agrícola — a ausência degrada a missão, não a segurança |
| comunicacao | Equipamento de comunicação — a ausência tira a telemetria |

**A ausência de uma câmera de inspeção não pode impedir a inicialização nem a navegação.**
A ausência de LiDAR, GNSS ou IMU tem de impedir. É requisito de software, e a distinção
existe para que o rover continue trabalhando com uma câmera queimada em vez de parar na
lavoura.

## Energia e rede com nove câmeras

| Grandeza | Valor | Situação |
|---|---|---|
| 9 × OAK-D a 12.95 W (teto 802.3af classe 3) | 116.5 W | — |
| 2 × térmica opcional | 6.0 W | opcional |
| Terminal satelital (provisão) | 30 W | provisão |
| **Total com 15 % de perda de PoE** | **174 W** | conversor de 360 W: **cabe**, folga 186 W |
| Portas Ethernet necessárias | 10 | switch de 8: **não serve** |
| Banda agregada | 540 Mbit/s | 54 % de um uplink de 1 Gbit/s |

**A 9ª câmera não dói na energia — dói na rede.** São 10 portas com o LiDAR, e o switch PoE
de 8 não atende. Trocar por um de 12 portas PoE+ é **item novo de BOM**, não ajuste de
desenho. Pendência P-31.

## O que o software tem de fazer

| Requisito | O que significa |
|---|---|
| Identificação do módulo | Cada posto VMS tem um identificador físico. O software lê o número de série da câmera na enumeração Ethernet e o associa ao POSTO, não ao equipamento — é o posto que tem calibração extrínseca, não a peça. |
| Detecção de desconexão | Perda de enumeração por mais de 2 s = módulo ausente. O sistema registra, segue operando e marca os dados daquele posto como indisponíveis. |
| Operação degradada | A ausência de qualquer câmera de INSPEÇÃO não impede a inicialização nem a navegação. A ausência de LiDAR, GNSS ou IMU — classe navegação — impede, e isso é projeto, não falha. |
| Perfil por modelo | Cada modelo de sensor tem um perfil: driver, resolução, taxa, intrínsecos de fábrica e limites. Trocar o modelo num posto troca o perfil, não o código. |
| Verificação de calibração após troca | Ao detectar número de série novo num posto conhecido, o sistema exige a verificação: alvo conhecido, erro de reprojeção medido, aceite se abaixo do limite de 0.1°. Com pino de referência o esperado é passar de primeira. |
| Detecção de perda de referência | Se a braçadeira T-01 for afrouxada, a extrínseca muda e o pino não protege. O software NÃO tem como saber sozinho — por isso o procedimento de manutenção exige registro manual, e é a maior fragilidade desta arquitetura. Ver `pendencias`. |
| Sincronização temporal | Todos os fluxos com carimbo de tempo da mesma base. Um módulo novo sem sincronização entra como fluxo isolado, não entra na fusão. |
| Interface com o SaaS | Inventário de módulos por rover, com posto, modelo, número de série e data da última calibração. NOT_IMPLEMENTED no SaaS. |


## Trocar um sensor em campo

| n | O que fazer | Por quê |
|---|---|---|
| 1 | Desligar o rover e travar o sistema de ar no vão mínimo | segurança |
| 2 | Desconectar o M12 do posto | o conector é o único ponto elétrico |
| 3 | Soltar os 4 parafusos M5 do adaptador T-03 | chave Allen 3 mm |
| 4 | Retirar o adaptador com a câmera | os pinos de referência FICAM no prato T-02 |
| 5 | NÃO tocar na braçadeira T-01 | é o que preserva a calibração extrínseca |
| 6 | Montar o adaptador novo nos pinos, apertar os 4 M5 a 5 N·m | cruzado |
| 7 | Reconectar o M12 e ligar | o sistema detecta o número de série novo |
| 8 | Rodar a verificação de calibração do posto | alvo conhecido, 2 minutos |
| 9 | Registrar no inventário: posto, modelo, série, data | rastreabilidade |

**O passo 5 é o que importa:** não tocar na braçadeira T-01. É ela que define altura e
azimute, e é a única camada cuja alteração exige recalibrar.

## Ensaios que esta arquitetura exige

| Cód. | Ensaio | Aceite |
|---|---|---|
| V-10 | Repetibilidade da interface VMS | Montar e desmontar o mesmo adaptador 10 vezes, medindo a orientação com alvo a 5 m. Aceite: dispersão abaixo de 0,1°. É o ensaio que valida ou derruba o argumento do pino. |
| V-11 | Grau de proteção do posto montado | Jato e poeira conforme IEC 60529 no conjunto conector + cabo + câmera. Sem isto o projeto NÃO declara IP. |
| V-12 | Vibração do mastro em campo | Acelerômetro nos três andares, percurso de 1 km em rua de café. Mede o espectro real e fecha a margem de frequência que hoje é critério, não medição. |
| V-13 | Impacto de galho no protetor | Carga lateral progressiva no protetor T-05 até a ruptura. Aceite: o protetor rompe antes do adaptador, e a câmera sobrevive. |
| V-14 | Troca em campo cronometrada | Técnico com ferramenta de campo troca uma câmera do andar alto. Aceite: abaixo de 10 minutos, sem recalibração. |
| V-15 | Operação com módulo ausente | Desconectar cada câmera de inspeção, uma por vez, com o rover em missão. Aceite: nenhuma interrupção de navegação. |

**Nenhum destes ensaios foi feito.** O V-10 é o que valida ou derruba o argumento do pino,
que é a base de toda esta arquitetura — enquanto ele não rodar, a repetibilidade calculada
é cálculo, não medição.

## Pendências

| Cód. | Assunto | Grau | O que falta |
|---|---|---|---|
| **P-06** | Desenho dimensional da OAK-D Pro W PoE | CRÍTICA | Bloqueia a furação do adaptador T-03, que é a peça que define a modularidade. Os 4 furos Ø3,4 desenhados são PROVISÃO — a furação real vem do fabricante. Sem ela, T-03 não é cota de fabricação. |
| **P-30** | Modelo da câmera térmica | ALTA | Nenhum escolhido. O adaptador T-04 existe como REQUISITO: uma chapa 72×64×6 com a face VMS-60 de um lado e a furação do modelo do outro. É 1 peça de corte a laser por modelo adotado. |
| **P-31** | Switch PoE de 12 portas | ALTA | A 9ª câmera estoura o switch de 8 portas. Item NOVO de BOM, não previsto no V3. |
| **P-32** | Terminal de comunicação por satélite | MÉDIA | Provisão desenhada para até 220 × 240 × 40 mm. Um terminal da classe 300 × 260 — que é a do Starlink Mini — NÃO CABE sem deslocar o suporte do LiDAR ou a antena GNSS. |
| **P-33** | Detecção de afrouxamento da braçadeira | MÉDIA | O software detecta troca de módulo, mas não detecta que alguém mexeu na altura. É a fragilidade da arquitetura, e hoje só o procedimento cobre. |
| **P-34** | Grau de proteção IP do posto | MÉDIA | Não declarado, por não ter ensaio. Ensaio V-11. |
| **P-35** | Campo de visão real da OAK-D Pro W | MÉDIA | 128° × 80° são os valores divulgados, não ficha técnica no projeto. O protetor T-05 é dimensionado por eles; se mudarem, redimensiona. |