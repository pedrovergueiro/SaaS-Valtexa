# Rover V4 — rigidez do mastro e vibração dos sensores

> **VTX-RV4 · Revisão H · 11/10/2026**
> EMITIDO PARA COTAÇÃO E VALIDAÇÃO — NÃO LIBERADO PARA FABRICAÇÃO
>
> Documento **gerado** de `revisao-h/mastro.py` sobre a geometria de
> `chassi-gaiola/modelo.py`. Não editar à mão: a próxima geração sobrescreve.


## O achado

O caso 6 do FEA — *"1ª frequência do mastro ≥ 7,5 Hz"* — estava aberto desde a Rev E e
**nunca tinha sido verificado**. O V4 verificou.

Com o tubo Ø25 × 2 herdado da baseline, a primeira frequência de flexão do mastro é
**6.53 Hz**. O requisito é 7,5. E a excitação estimada do terreno a
1.4 m/s é **5.60 Hz** — razão de **1,16**.

1,16 não é margem apertada. É a faixa onde a resposta **amplifica**: o mastro estava
praticamente em ressonância com o chão da lavoura, com três câmeras no alto.

## A correção

| Grandeza | Ø25 × 2 (V3) | Ø32 × 2 (V4) |
|---|---|---|
| Momento de inércia | 9628 mm⁴ | 21300 mm⁴ |
| **1ª frequência de flexão** | **6.53 Hz** | **9.40 Hz** |
| Contra o requisito de 7,5 Hz | reprovado | aprovado |
| Razão contra a excitação | 1,16 | 1.68 |
| Rotação da câmera alta sob galho de 80 N | 5.25° | 2.37° |
| Erro de apontamento a 10 m | 918 mm | 414 mm |
| Massa dos dois mastros | — | +0.30 kg |

A luva M-01 acompanha: Ø42 × 5, contra Ø34 × 4,5 do V3. E o eixo do mastro recua de
|Y| 280 para 276 — a luva Ø42 em 280 chegaria a 301, fora do envelope externo de 600.

## Todas as seções avaliadas

| Seção | I (mm⁴) | f (Hz) | Δmassa (2 mastros) | Rotação sob galho | Erro a 10 m |
|---|---|---|---|---|---|
| Ø25 × 2 — como está (herdado da baseline) ← abaixo do requisito | 9628 | 6.53 | +0.000 kg | 5.25° | 918 mm |
| Ø25 × 2,5 ← abaixo do requisito | 11321 | 6.91 | +0.218 kg | 4.46° | 781 mm |
| Ø30 × 2 | 17329 | 8.56 | +0.213 kg | 2.92° | 509 mm |
| Ø32 × 2 ← **adotada** | 21300 | 9.40 | +0.298 kg | 2.37° | 414 mm |
| Ø35 × 2 | 28329 | 10.70 | +0.426 kg | 1.78° | 311 mm |
| Ø38 × 2 | 36757 | 12.03 | +0.554 kg | 1.37° | 240 mm |


## De onde vem a excitação

| Fonte | Frequência |
|---|---|
| Terreno a 1.4 m/s, onda de 0.25 m | 5.60 Hz |
| Suspensão pneumática (frequência de canto) | 1.95 Hz |
| Rotação da roda | 2.23 Hz |

A suspensão pneumática **filtra** o terreno acima da própria frequência de
1.95 Hz. O que chega ao mastro é o que passa por ela.

> O comprimento de onda de 0.25 m é **critério de projeto, não
> medição**. É o ensaio V-12 que fecha esta margem — e fechá-la medindo é melhor
> engenharia que engrossar o tubo às cegas.

## Sensibilidade à massa da câmera

A massa da OAK-D é **estimativa** (pendência P-06). O resultado é robusto a ela:

| Massa da câmera | Frequência | Atende? |
|---|---|---|
| 0.15 kg | 9.90 Hz | sim |
| 0.20 kg | 9.64 Hz | sim |
| 0.25 kg | 9.40 Hz | sim |
| 0.35 kg | 8.97 Hz | sim |
| 0.50 kg | 8.42 Hz | sim |


## Rigidez do mastro não é isolamento do sensor

O pedido do V4 manda diferenciar as duas coisas. A diferença não é de grau — é de sinal.

| | Enrijecer o mastro | Isolar a câmera |
|---|---|---|
| O que faz | sobe a frequência própria para longe da excitação | desacopla a câmera do mastro |
| Efeito na imagem | reduz a amplitude do movimento | reduz o borrão de alta frequência |
| Efeito na calibração | **nenhum** — a câmera segue solidária ao rover | **destrói** — a extrínseca passa a depender da aceleração |

Isolar a câmera resolveria o borrão e criaria um problema maior.

A fusão de dados da IA usa a matriz extrínseca de cada câmera — onde ela está e para onde
aponta, em relação ao referencial do rover. Essa matriz é medida uma vez, na calibração, e
tratada como **constante**. Num mount rígido ela é constante de verdade: a câmera
acompanha o rover.

Num mount isolado ela deixa de ser. A câmera passa a se mover em relação ao chassi em
função da aceleração instantânea, com amplitude de milímetros e defasagem de fase. A
reconstrução 3D passa a ter um erro que varia com o terreno e que **nenhuma calibração
estática corrige**, porque não é um offset — é uma função do movimento.

Entre uma imagem com algum borrão de movimento e uma nuvem de pontos com erro variável de
origem desconhecida, a primeira é recuperável (obturador mais rápido, ganho maior,
estabilização auxiliada por IMU) e a segunda não.

Por isso: **câmera rígida, mastro rígido o bastante, e o problema de vibração resolvido
onde ele nasce.**


### O único sensor isolado continua sendo o LiDAR

E isolar o LiDAR está certo, porque ele é o caso oposto: mede distância instantânea ponto
a ponto, não integra imagem no tempo, e a extrínseca dele precisa valer na média.

Os coxins G-08 já existem desde a Rev E. A conta de verificação:

| | Valor |
|---|---|
| 4 coxins a 120 N/mm sob 0.30 kg | 201 Hz |
| Razão contra a excitação | 36× |
| Isola ou amplifica? | **isola** |

> Isolador só atenua acima de √2 vezes a própria frequência. Abaixo disso ele **amplifica**.
> A conta depende da massa do LiDAR, que é estimativa (P-11).

## Tensão no mastro

| | Valor |
|---|---|
| Carga de galho de projeto | 80 N na ponta |
| Momento na raiz | 100480 N·mm |
| Tensão | 75.5 MPa |
| Fator de segurança | 3.18 |

O galho governa. Vento de 20 m/s não é o caso crítico de um mastro de Ø25 — a área projetada é pequena demais.

## O que continua aberto

- **massa real da OAK-D** (P-06) — a frequência é robusta a ela, o apontamento não;
- **espectro real de vibração em campo** (ensaio V-12) — hoje a excitação é critério;
- **FEA do caso 6** — este cálculo é analítico, por Rayleigh, com forma suposta. Ele diz
  que Ø25 reprovava e que Ø32 passa; não substitui o modelo de elementos finitos.
