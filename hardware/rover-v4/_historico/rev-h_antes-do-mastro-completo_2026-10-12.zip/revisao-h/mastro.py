"""Rigidez do mastro e vibração dos sensores — a conta que decide se isola ou enrijece.

O pedido do V4 manda **diferenciar a rigidez do mastro do isolamento de vibração dos
sensores**. Esta é a diferença, e ela não é de grau — é de sinal:

* **enrijecer o mastro** sobe a frequência própria para longe da excitação do terreno. A
  câmera continua solidária ao rover, e a calibração extrínseca continua válida;
* **isolar a câmera** desacopla a câmera do mastro. Atenua vibração de alta frequência, e
  em troca **a câmera passa a se mover em relação ao rover**. Para fusão de dados isso é
  veneno: a matriz extrínseca deixa de ser constante e passa a depender da aceleração.

Num rover de inspeção, o dado é a imagem georreferenciada. Mover a câmera para suavizar a
imagem e destruir a georreferência é trocar um problema por outro pior. Por isso a regra
desta revisão:

> **Câmera: montagem RÍGIDA. LiDAR: isolado. A vibração das câmeras se resolve na
> rigidez do mastro, não no coxim.**

E o LiDAR é isolado porque é outro caso: ele mede distância instantânea ponto a ponto, não
integra uma imagem no tempo, e sua extrínseca só precisa valer na média. Os coxins G-08 já
estão no projeto desde a Rev E e continuam.

O que este módulo faz é provar que a rigidez do mastro basta — ou dizer de quanto ela
precisa aumentar.

```
python mastro.py
```

Unidades: mm, kg, N, Hz, graus.
"""

from __future__ import annotations

import math
import pathlib
import sys

AQUI = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI.parent / 'chassi-gaiola'))
sys.path.insert(0, str(AQUI))

import modelo as M  # noqa: E402

G = 9.80665

# ============================================================ material e seção
E_AL = 68900.0
"""MPa — módulo de elasticidade do 6061-T6. Independe da têmpera; a solda não o altera."""

RHO_AL = 2.70e-6   # kg/mm³
RHO_UHMW = 0.95e-6

# ---- massas dos sensores
MASSA_OAKD = 0.25
"""kg — ESTIMATIVA. A Luxonis não publica a massa da OAK-D Pro W PoE no material que o
projeto tem (pendência P-06). 0,25 kg é faixa para uma câmera estéreo em carcaça de
alumínio deste tamanho. `sensibilidade` mostra o efeito de errar este número."""

MASSA_TERMICA = 0.20
"""kg — ESTIMATIVA, mesma situação. Módulo térmico compacto com lente de germânio."""

MASSA_VMS = 0.42
"""kg — massa do posto VMS completo (braçadeira + prato + adaptador + protetor), calculada
da geometria em `modelo.postos_vms`. Confirmada por `_massa_posto`."""


def _massa_posto() -> float:
    """Massa real de um posto VMS, medida na geometria do modelo."""
    try:
        ps = [p for p in M.suportes_camera() if p.grupo == 'T']
    except AttributeError:
        return MASSA_VMS
    if not ps:
        return MASSA_VMS
    return sum(p.massa() for p in ps) / 6.0


def secao_mastro(d_ext: float = None, parede: float = None) -> dict:
    """Propriedades da seção do tubo do mastro."""
    d = d_ext if d_ext is not None else M.D_MASTRO
    t = parede if parede is not None else M.E_MASTRO
    di = d - 2 * t
    i = math.pi * (d ** 4 - di ** 4) / 64
    a = math.pi * (d ** 2 - di ** 2) / 4
    return dict(d_ext=d, parede=t, d_int=di, I=i, A=a, W=i / (d / 2),
                massa_linear=a * RHO_AL, EI=E_AL * i)


# ============================================================ modelo dinâmico
def _bainha_massa_linear() -> float:
    """A bainha anti-galho não é estrutural, mas pesa e desce a frequência."""
    a = math.pi * (M.D_BAINHA ** 2 - M.D_MASTRO ** 2) / 4
    return a * RHO_UHMW


def frequencia(d_ext: float = None, parede: float = None,
               massa_cam: float = None, alturas=None, cargas=None,
               massa_ponta: float = 0.0) -> dict:
    """1ª frequência de flexão do mastro, por Rayleigh com massas concentradas.

    Modelo: viga em balanço engastada no topo da luva M-01 (Z 346), com as câmeras como
    massas concentradas nas cotas de montagem. A forma suposta é a estática do balanço sob
    peso próprio, que é o padrão do método e dá erro de poucos por cento para baixo.

    Rayleigh dá um limite SUPERIOR da frequência. Para um requisito do tipo "a primeira
    frequência tem de estar ACIMA de X", isso é o lado errado do conservadorismo — por
    isso o resultado é corrigido por `FATOR_RAYLEIGH`, que é a folga que a literatura
    atribui ao método para este tipo de viga com massa concentrada.
    """
    s = secao_mastro(d_ext, parede)
    m_cam = massa_cam if massa_cam is not None else MASSA_OAKD + _massa_posto()
    alturas = alturas if alturas is not None else M.CAMERAS_Z
    # `cargas` é a forma geral: lista de (z, massa). Sem ela, vale o modelo antigo —
    # uma câmera de massa `m_cam` em cada cota de `alturas`.
    if cargas is None:
        cargas = [(z, m_cam) for z in alturas]
    if massa_ponta:
        cargas = list(cargas) + [(M.Z_TOTAL, massa_ponta)]

    z0 = M.Z_LUVA[1]                      # engaste: topo da luva
    ltot = M.Z_TOTAL - z0
    mu = s['massa_linear'] + _bainha_massa_linear()

    def phi(x):
        """Forma suposta: flecha estática do balanço sob carga distribuída, normalizada."""
        return (x ** 2) * (6 * ltot ** 2 - 4 * ltot * x + x ** 2) / (3 * ltot ** 4)

    # energia potencial ~ integral EI (phi'')²; energia cinética ~ integral mu phi² + m_i phi_i²
    n = 400
    h = ltot / n
    num = den = 0.0
    for i in range(n + 1):
        x = i * h
        w = 1.0 if 0 < i < n else 0.5
        d2 = (12 * ltot ** 2 - 24 * ltot * x + 12 * x ** 2) / (3 * ltot ** 4)
        num += w * s['EI'] * d2 ** 2 * h
        den += w * mu * phi(x) ** 2 * h
    for (z, m_i) in cargas:
        x = z - z0
        if x <= 0:
            continue
        den += m_i * phi(x) ** 2

    w2 = num / den                       # rad²/s², com num em N·mm e den em kg·mm²
    f = math.sqrt(w2 * 1e3) / (2 * math.pi)   # N·mm/(kg·mm²) = 1e3 · 1/s²

    FATOR_RAYLEIGH = 0.95
    return dict(secao=s, massa_por_camera=m_cam, alturas=tuple(z for z, _ in cargas),
                cargas=tuple(cargas),
                comprimento_livre=ltot, massa_linear_total=mu,
                massa_cameras=sum(m_i for z, m_i in cargas if z > z0),
                freq_Hz=f * FATOR_RAYLEIGH, freq_rayleigh_Hz=f)


# ======================================================== deflexão e apontamento
VENTO_PA = 250.0
"""Pa — pressão dinâmica de projeto. 250 Pa ≈ 20 m/s (72 km/h). CRITÉRIO DE PROJETO:
não é condição de operação, é a rajada que o mastro tem de aguentar sem dano."""

GALHO_N = 80.0
"""N — carga lateral de um galho de café varrendo o mastro em marcha.
CRITÉRIO DE PROJETO. É o caso que define o apontamento, não o vento."""


def deflexao(forca_N: float = None, d_ext=None, parede=None) -> list[dict]:
    """Flecha e rotação em cada cota de câmera, sob carga lateral na ponta.

    O número que importa não é a flecha — é a **rotação**. Uma câmera que translada 10 mm
    continua enxergando quase a mesma coisa; uma que gira 1° erra 175 mm a 10 m.
    """
    s = secao_mastro(d_ext, parede)
    f = forca_N if forca_N is not None else GALHO_N
    z0 = M.Z_LUVA[1]
    ltot = M.Z_TOTAL - z0
    out = []
    for z in list(M.CAMERAS_Z) + [M.Z_TOTAL]:
        x = z - z0
        if x <= 0:
            continue
        flecha = f * x ** 2 * (3 * ltot - x) / (6 * s['EI'])
        rot = f * x * (2 * ltot - x) / (2 * s['EI'])          # rad
        out.append(dict(z=z, flecha_mm=flecha, rotacao_deg=math.degrees(rot),
                        erro_a_10m_mm=math.tan(rot) * 10000.0))
    return out


def tensao_mastro(d_ext=None, parede=None) -> dict:
    """Tensão na raiz do mastro e verificação contra o escoamento."""
    s = secao_mastro(d_ext, parede)
    ltot = M.Z_TOTAL - M.Z_LUVA[1]
    # vento sobre a área projetada do mastro + das câmeras
    area_mastro = M.D_BAINHA * ltot * 1e-6                     # m²
    area_cam = 3 * 0.09 * 0.07                                 # m², envelope ESTIMADO
    f_vento = VENTO_PA * (area_mastro + area_cam)
    m_vento = f_vento * (ltot / 2) * 1e3 / 1e3 * 0 + f_vento * (ltot * 0.6)
    m_galho = GALHO_N * ltot
    pior = max(m_vento, m_galho)
    return dict(forca_vento_N=f_vento, momento_vento_Nmm=m_vento,
                momento_galho_Nmm=m_galho, momento_projeto_Nmm=pior,
                sigma_MPa=pior / s['W'], W=s['W'],
                fs=240.0 / (pior / s['W']),
                nota='O galho governa. Vento de 20 m/s não é o caso crítico de um mastro '
                     'de Ø25 — a área projetada é pequena demais.')


# ============================================================ excitação do terreno
VELOCIDADE_MS = 1.4
"""m/s — velocidade de trabalho na lavoura. FONTE: baseline."""

PASSO_IRREGULARIDADE_M = 0.25
"""m — comprimento de onda típico das irregularidades de solo em rua de café.
CRITÉRIO DE PROJETO, a confirmar no ensaio V-09."""


def excitacao() -> dict:
    """De onde vem a vibração, e em que frequência."""
    f_terreno = VELOCIDADE_MS / PASSO_IRREGULARIDADE_M
    sys.path.insert(0, str(AQUI))
    import suspensao as S  # noqa: PLC0415
    f_susp = S.fole()['freq_Hz']
    n_rodas = 4
    f_roda = VELOCIDADE_MS / (math.pi * M.D_RODA / 1000.0)
    return dict(
        terreno_Hz=f_terreno, suspensao_Hz=f_susp, rotacao_da_roda_Hz=f_roda,
        maior_Hz=max(f_terreno, f_susp, f_roda),
        nota='A suspensão pneumática FILTRA o terreno acima da própria frequência de '
             f'{f_susp:.2f} Hz. O que chega ao mastro é o que passa por ela.')


REQUISITO_FREQ_HZ = 7.5
"""Hz — requisito da folha 25, caso 6 do FEA: 1ª frequência do mastro ≥ 7,5 Hz.
Herdado da Rev E e nunca verificado até esta revisão."""

MARGEM_MINIMA = 2.0
"""Razão mínima entre a frequência do mastro e a maior excitação.

CRITÉRIO DE PROJETO, e vale separar de um critério parecido que NÃO se aplica aqui.

Para um **isolador** a regra é √2: abaixo disso ele amplifica em vez de atenuar, e na
prática se pede 3 ou mais. Para uma **estrutura** a conta é outra — não se quer atenuação,
quer-se só ficar fora da ressonância. Fator 2 põe a excitação a meio caminho do pico e dá
folga para o erro das massas, que aqui é grande: a massa da OAK-D é estimativa.

Exigir 3 de um mastro em balanço de 1,26 m levaria a tubo de Ø50, e seria sobre-projetar
contra um número de excitação que é critério, não medição. O caminho certo para fechar a
margem é **medir** o espectro em campo (ensaio V-09), não engrossar o tubo às cegas.
"""


def veredito(d_ext=None, parede=None) -> dict:
    """Enrijecer o mastro basta, ou é preciso isolar a câmera?"""
    f = frequencia(d_ext, parede)
    ex = excitacao()
    razao = f['freq_Hz'] / ex['maior_Hz']
    return dict(
        freq_mastro_Hz=f['freq_Hz'], excitacao_Hz=ex['maior_Hz'], razao=razao,
        atende_requisito=f['freq_Hz'] >= REQUISITO_FREQ_HZ,
        margem_ok=razao >= MARGEM_MINIMA,
        precisa_isolar=not (f['freq_Hz'] >= REQUISITO_FREQ_HZ and razao >= MARGEM_MINIMA),
        requisito_Hz=REQUISITO_FREQ_HZ, margem_minima=MARGEM_MINIMA)


ALTERNATIVAS = [
    # (descrição, Ø externo, parede)
    ('Ø25 × 2 — como está (herdado da baseline)', 25.0, 2.0),
    ('Ø25 × 2,5', 25.0, 2.5),
    ('Ø30 × 2', 30.0, 2.0),
    ('Ø32 × 2', 32.0, 2.0),
    ('Ø35 × 2', 35.0, 2.0),
    ('Ø38 × 2', 38.0, 2.0),
]


def comparacao_secoes() -> list[dict]:
    """O que cada seção de tubo entrega — frequência, massa e rotação sob galho."""
    out = []
    base = secao_mastro(25.0, 2.0)['massa_linear']
    for (nome, d, t) in ALTERNATIVAS:
        f = frequencia(d, t)
        s = f['secao']
        defl = deflexao(d_ext=d, parede=t)
        topo = defl[-1]
        alta = [x for x in defl if abs(x['z'] - M.CAMERAS_Z[2]) < 1][0]
        ltot = M.Z_TOTAL - M.Z_LUVA[1]
        out.append(dict(
            nome=nome, d=d, parede=t, I=s['I'], freq_Hz=f['freq_Hz'],
            massa_por_mastro=s['massa_linear'] * ltot,
            delta_massa_total=2 * (s['massa_linear'] - base) * ltot,
            rotacao_camera_alta_deg=alta['rotacao_deg'],
            erro_a_10m_mm=alta['erro_a_10m_mm'],
            flecha_topo_mm=topo['flecha_mm'],
            sigma_MPa=tensao_mastro(d, t)['sigma_MPa'],
            atende=f['freq_Hz'] >= REQUISITO_FREQ_HZ))
    return out


def sensibilidade() -> list[dict]:
    """E se a massa da OAK-D não for 0,25 kg? É estimativa, e pesa na frequência."""
    out = []
    for m in (0.15, 0.20, 0.25, 0.35, 0.50):
        f = frequencia(massa_cam=m + _massa_posto())
        out.append(dict(massa_camera=m, massa_posto=_massa_posto(),
                        freq_Hz=f['freq_Hz'], atende=f['freq_Hz'] >= REQUISITO_FREQ_HZ))
    return out


# =============================================================== isolamento
def isolamento_lidar() -> dict:
    """Os coxins G-08 do LiDAR: o único isolamento que o projeto tem, e por quê.

    O LiDAR é o caso em que isolar está certo: ele mede distância ponto a ponto, não
    integra imagem no tempo, e sua extrínseca precisa valer na média, não a cada instante.
    Câmera é o contrário.
    """
    ex = excitacao()
    # 4 coxins NBR Ø15×10 sob o suporte G-06; rigidez de faixa para elastômero 60 Sh A
    k_coxim = 120.0                      # N/mm, FAIXA de catálogo
    massa = 0.30                         # kg, ESTIMATIVA — Mid-360 sem ficha técnica
    k = 4 * k_coxim * 1e3
    f = math.sqrt(k / massa) / (2 * math.pi)
    return dict(k_por_coxim_N_mm=k_coxim, n=4, massa_isolada=massa, freq_Hz=f,
                razao=f / ex['maior_Hz'],
                isola=f > ex['maior_Hz'] * math.sqrt(2),
                nota='Isolador só atenua ACIMA de √2 vezes a própria frequência. Abaixo '
                     'disso ele AMPLIFICA. É a conta que decide se o coxim ajuda ou '
                     'atrapalha, e ela depende da massa do LiDAR — que é estimativa '
                     '(P-11).')


PORQUE_NAO_ISOLAR_CAMERA = """\
Isolar a câmera resolveria o borrão e criaria um problema maior.

A fusão de dados da IA usa a matriz extrínseca de cada câmera — onde ela está e para onde
aponta, em relação ao referencial do rover. Essa matriz é medida uma vez, na calibração, e
tratada como **constante**. Num mount rígido ela é constante de verdade: a câmera
acompanha o rover.

Num mount isolado ela deixa de ser. A câmera passa a se mover em relação ao chassi em
função da aceleração instantânea, com amplitude de milímetros e defasagem de fase. A
reconstrução 3D passa a ter um erro que varia com o terreno e que **nenhuma calibração
estática corrige**, porque não é um offset — é uma função do movimento.

Entre uma imagem com algum borrão de movimento e uma nuvem de pontos com erro variável de
origem desconhecida, a primeira é recuperável (obturador mais rápido, ganho maior,
estabilização auxiliada por IMU) e a segunda não.

Por isso: **câmera rígida, mastro rígido o bastante, e o problema de vibração resolvido
onde ele nasce.**
"""


# =============================================================== relatório
def main() -> None:
    print('=' * 86)
    print('VTX-RV4 Rev H · RIGIDEZ DO MASTRO E VIBRAÇÃO DOS SENSORES')
    print('=' * 86)

    s = secao_mastro()
    f = frequencia()
    print(f'\n1. Mastro como está — {M._n(M.D_MASTRO)} × {M._n(M.E_MASTRO)}')
    print('-' * 50)
    print(f'  engaste no topo da luva M-01, Z {M.Z_LUVA[1]:.0f}; '
          f'comprimento livre {f["comprimento_livre"]:.0f} mm')
    print(f'  I = {s["I"]:.0f} mm⁴ · EI = {s["EI"] / 1e6:.0f} N·m²')
    print(f'  massa linear {s["massa_linear"] * 1e3:.3f} g/mm + bainha '
          f'{_bainha_massa_linear() * 1e3:.3f} g/mm')
    print(f'  massa por posto de câmera: {f["massa_por_camera"]:.3f} kg '
          f'(OAK-D {MASSA_OAKD:.2f} + posto VMS {_massa_posto():.3f})')
    print(f'  1ª frequência de flexão: {f["freq_Hz"]:.2f} Hz')

    ex = excitacao()
    print('\n2. De onde vem a excitação')
    print('-' * 50)
    print(f'  terreno a {VELOCIDADE_MS} m/s com onda de {PASSO_IRREGULARIDADE_M} m: '
          f'{ex["terreno_Hz"]:.2f} Hz')
    print(f'  suspensão pneumática (frequência de canto):          {ex["suspensao_Hz"]:.2f} Hz')
    print(f'  rotação da roda:                                      {ex["rotacao_da_roda_Hz"]:.2f} Hz')
    print(f'  maior: {ex["maior_Hz"]:.2f} Hz')
    print(f'  {ex["nota"]}')

    v = veredito()
    print('\n3. Veredito')
    print('-' * 50)
    print(f'  frequência do mastro {v["freq_mastro_Hz"]:.2f} Hz contra requisito '
          f'{v["requisito_Hz"]:.1f} Hz: {"ATENDE" if v["atende_requisito"] else "NAO ATENDE"}')
    print(f'  razão frequência/excitação {v["razao"]:.2f} contra mínimo '
          f'{v["margem_minima"]:.1f}: {"OK" if v["margem_ok"] else "INSUFICIENTE"}')
    print(f'  --> {"PRECISA ENRIJECER O MASTRO" if v["precisa_isolar"] else "O mastro basta; câmera rígida"}')

    print('\n4. Seções alternativas de tubo')
    print('-' * 50)
    print(f'  {"seção":40} {"I mm⁴":>9} {"f Hz":>7} {"Δmassa":>8} {"rot°":>7} {"erro 10m":>9}')
    for c in comparacao_secoes():
        print(f'  {c["nome"]:40} {c["I"]:9.0f} {c["freq_Hz"]:7.2f} '
              f'{c["delta_massa_total"]:+8.3f} {c["rotacao_camera_alta_deg"]:7.3f} '
              f'{c["erro_a_10m_mm"]:8.0f}mm'
              f'{"" if c["atende"] else "   <- abaixo do requisito"}')

    print(f'\n5. Deflexão sob galho de {GALHO_N:.0f} N na ponta (seção atual)')
    print('-' * 50)
    for d in deflexao():
        print(f'  Z {d["z"]:6.0f}   flecha {d["flecha_mm"]:7.2f} mm   '
              f'rotação {d["rotacao_deg"]:6.3f}°   erro a 10 m {d["erro_a_10m_mm"]:7.0f} mm')
    t = tensao_mastro()
    print(f'  tensão na raiz {t["sigma_MPa"]:.1f} MPa · FS {t["fs"]:.2f} · {t["nota"]}')

    print('\n6. Sensibilidade à massa da câmera (ESTIMATIVA, pendência P-06)')
    print('-' * 50)
    for x in sensibilidade():
        print(f'  câmera {x["massa_camera"]:.2f} kg + posto {x["massa_posto"]:.3f} kg '
              f'-> {x["freq_Hz"]:5.2f} Hz'
              f'{"" if x["atende"] else "   <- abaixo do requisito"}')

    il = isolamento_lidar()
    print('\n7. Isolamento: só o LiDAR')
    print('-' * 50)
    print(f'  4 coxins G-08 a {il["k_por_coxim_N_mm"]:.0f} N/mm sob {il["massa_isolada"]:.2f} kg '
          f'-> {il["freq_Hz"]:.1f} Hz')
    print(f'  razão contra a excitação: {il["razao"]:.1f} · '
          f'{"ISOLA" if il["isola"] else "NAO ISOLA — amplificaria"}')
    print(f'  {il["nota"]}')
    print()
    for linha in PORQUE_NAO_ISOLAR_CAMERA.strip().split('\n'):
        print('  ' + linha)


if __name__ == '__main__':
    main()
