# ValTexa Rover **V4** — engenharia mecânica

**Revisão atual: H** (11/10/2026) · EMITIDO PARA COTAÇÃO E VALIDAÇÃO — **NÃO LIBERADO PARA
FABRICAÇÃO**

> O **V3** está preservado, inteiro e intocado, em `../rover-v3`. Nada lá foi sobrescrito.

---

## Por que V4, e por que a revisão continua em H

O **número de versão** mudou porque a arquitetura de sensores mudou: a interface deixou de
ser uma chapa furada e passou a ser um sistema modular com pino de referência.

A **letra de revisão** continua em H, em vez de recomeçar em A, porque o hardware é
contínuo: chassi, suspensão pneumática, gaiola e carenagens são os mesmos da Rev G do V3,
sem uma cota alterada. Recomeçar em "A" sugeriria uma baseline nova que não existe, e toda
referência a Rev E, F e G neste caderno aponta para o histórico do V3.

## O que o V4 mudou

| Área | V3 | V4 |
|---|---|---|
| Interface de sensores | chapa M-20, furação fixa, padrão da câmera "a validar" | **grupo T — VMS-60**: braçadeira deslizante, prato com pinos, adaptador por modelo |
| Câmeras | 8 declaradas; a frontal **não existia no desenho**, a traseira não existia | **9 postos**, todos desenhados, todos com a mesma face |
| Mastro | Ø25 × 2 — **6,53 Hz**, abaixo do requisito de 7,5 e quase em ressonância | **Ø32 × 2 — 9,40 Hz** |
| Vibração | não calculada | **câmera rígida, LiDAR isolado**, com a conta de cada um |
| Proteção | carenagem N-09, por semelhança | **protetor T-05 sacrificial**, dimensionado pelo campo de visão |
| Térmicas | não previstas | **adaptador T-04 como requisito** — 1 peça por modelo |
| Satélite | zero ocorrências no projeto | **berço T-07**, envelope 220 × 240 × 40 |
| Caderno | 35 folhas | **40 folhas** |

### Os dois números que resumem o V4

**0,048° contra 1,10°.** É a repetibilidade da interface com pino de referência contra a
mesma interface só com parafuso. A 10 m de distância: 8,5 mm contra 192 mm. É esse fator de
23 que separa "removível" de "modular" — e é o que permite trocar uma câmera em campo sem
recalibrar.

**6,53 Hz contra 5,60 Hz.** Era a frequência do mastro do V3 contra a excitação estimada do
terreno. Razão 1,16 — praticamente ressonância, com três câmeras no alto. O caso 6 do FEA
estava aberto desde a Rev E e ninguém tinha verificado.

---

## O que há aqui

| Pasta | O que é |
|---|---|
| **`chassi-gaiola/`** | **o CAD.** Modelo paramétrico — dele saem as 40 folhas, os 36 DXF, as listas de corte e as massas |
| **`revisao-h/`** | cálculos e documentos, em `.py` e `.md`, com os PDFs em `revisao-h/pdf/` |
| **`pacote-rev-h/`** | gerador do pacote de cotação |
| `../rover-v3/` | o V3 completo, congelado |

## Para enviar à empresa que vai fabricar

```
pacote-rev-h/saida/VALTEXA_ROVER_V4_REV_H/
```

| Pasta | Conteúdo |
|---|---|
| `03_DESENHOS_TECNICOS/SENSORES_MODULARES/` | folhas 18, 19 e 36 a 40 — o que o V4 acrescentou |
| `03_DESENHOS_TECNICOS/SUSPENSAO_USINAGEM/` | folhas 07 e 28 a 31 — as peças de usinagem da suspensão |
| `03_DESENHOS_TECNICOS/MONTAGEM/` | folhas 32 a 35 — posição, sequência, torques, regulagem |
| `04_CAD/` | 36 DXF 1:1 e 5 STL |
| `05_BOM/` | 97 linhas |
| `11_ENGENHARIA_REV_H/` | os 10 documentos desta revisão |

## Para o engenheiro mecânico

| Documento | Assunto |
|---|---|
| `revisao-h/pdf/VTX-RV4-LIBERACAO-H.pdf` | **o escopo aprovado está duas revisões atrás** — leia antes de liberar |
| `revisao-h/pdf/VTX-RV4-MASTRO-H.pdf` | o mastro estava quase em ressonância; o que mudou e por quê |
| `revisao-h/pdf/VTX-RV4-MODULAR-H.pdf` | a interface VMS-60: repetibilidade, proteção, energia e banda |
| `revisao-h/pdf/VTX-RV4-SUSPENSAO-H.pdf` | a suspensão pneumática, inalterada desde a Rev G |
| `revisao-h/pdf/VTX-RV4-REGISTRO-ALTERACOES-H.pdf` | histórico V3 → V4, item a item |

## Para a oficina

| Documento | Assunto |
|---|---|
| `revisao-h/pdf/VTX-RV4-USINAGEM-H.pdf` | roteiro de operações peça por peça, 23 peças, 77 operações |
| `revisao-h/pdf/VTX-RV4-MONTAGEM-H.pdf` | posição de cada peça, sequência, torques, aceite |

---

## Regenerar tudo

```
cd chassi-gaiola && python gerar.py          # 40 folhas: HTML + 36 DXF + 6 PDFs
cd revisao-h     && python relatorios.py     # os 5 documentos gerados do modelo
cd revisao-h     && python gerar_docs.py     # PDF de todos os documentos
cd pacote-rev-h  && python gerar_pacote.py   # pacote de cotação completo
```

Os cálculos rodam sozinhos:

```
cd revisao-h
python mastro.py        # rigidez do mastro, vibração, isolamento   NOVO NO V4
python modular.py       # interface VMS-60, energia, banda          NOVO NO V4
python suspensao.py     # suspensão pneumática
python espaco.py        # espaço interno e interferência entre peças
python montagem.py      # mapa de posições, sequência, torques  (--item T-02)
python usinagem.py      # roteiro de usinagem                   (--item T-03)
python dimensional.py   # levantamento dimensional e 7 CSVs
```

## Onde mudar o quê

- **cota, material ou geometria** → `chassi-gaiola/modelo.py`
- **composição das folhas** → `folhas.py` (01–16), `folhas_b.py` (17–27), `folhas_w.py` (28–35), `folhas_t.py` (36–40)
- **padrão VMS-60** → `VMS_FUROS`, `VMS_PRATO`, `D_PINO_REF` em `modelo.py`. Um lugar só
- **sequência de montagem e torques** → `revisao-h/montagem.py`
- **tolerância e roteiro de usinagem** → `revisao-h/usinagem.py`

## Estado em uma linha

O V4 resolve a modularidade e acha dois defeitos que ninguém tinha visto: o mastro em
ressonância e a câmera frontal que existia só no papel. Continua faltando o FEA (9 casos,
nenhum rodado), a massa oficial, o modelo do fole, a ficha técnica da OAK-D e um switch de
12 portas que a 9ª câmera obriga. **Este pacote é para cotar, não para fabricar.**
